#!/usr/bin/env python3
"""
RNA-FLEEK Server — Load h5ad and serve to browser visualizer.

Requirements:
    pip install scanpy anndata numpy scipy

Usage:
    python fleek_server.py liver_census.h5ad
    python fleek_server.py liver_census.h5ad --port 8080 --max-cells 500000

Then open: http://localhost:8080
"""

import argparse
import io
import json
import os
import struct
import sys
import time
import threading
import warnings
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn
from pathlib import Path

# Suppress noisy pandas/scanpy warnings
warnings.filterwarnings("ignore", message="DataFrame is highly fragmented")
warnings.filterwarnings("ignore", category=FutureWarning)
from urllib.parse import urlparse, parse_qs

import numpy as np

# Globals set at startup
ADATA = None
UMAP_2D = None
UMAP_3D = None
PCA_2D = None
PCA_3D = None
PACMAP_2D = None
PACMAP_3D = None
PACMAP_COMPUTING = False
CLUSTER_IDS = None
CLUSTER_NAMES = None
GENE_NAMES_LIST = None
N_CELLS = 0
HTML_DIR = None
PROGRESS = {"status": "idle", "message": "", "pct": 0}  # for client polling
PROCESSING_LOCK = threading.Lock()
ABORT_REQUESTED = False  # Set True to cancel in-progress loading
ANNOT_STATUS = {"active": False, "method": "", "step": "", "pct": 0}  # For client polling
DEG_SETTINGS = {"fast": True, "max_cells": 50000}  # QuickDEG defaults
PACMAP_SETTINGS = {"fast": True, "max_cells": 50000}  # QuickPaCMAP defaults
PACMAP_FAST = True  # QuickMap (PaCMAP) — subsample-and-project
BACKED = False  # True if adata.X is on disk (backed mode)
X_CSC = None  # CSC copy of expression matrix for fast column access
HVG_NAMES = []  # ordered list of HVG names for the client
HVG_VAR = {}    # gene_name -> variance (for tooltip/list display)
ALL_GENE_VAR = None  # numpy array of variance for all genes (computed in background)
GENE_INDEX = {}  # gene_name -> column index
CSC_BUILDING = False  # True while background CSC build is running
CSC_CACHED = False    # True if CSC was loaded from cache
CSC_TIME = 0          # seconds taken to build/load CSC index
LOAD_SETTINGS = {}  # Sent to client so it knows what options were active
LOADED_PATH = ""    # path to currently loaded h5ad, for annotation caching
MARKER_DB = None    # {cell_type: [genes]} — loaded from file or built-in

# ── Built-in compact marker set for common human cell types ──
_BUILTIN_MARKERS = {
    "T cell": ["CD3D","CD3E","CD3G","CD2","TRAC","CD28"],
    "CD4+ T cell": ["CD3D","CD3E","CD4","IL7R","MAL","LEF1"],
    "CD8+ T cell": ["CD3D","CD3E","CD8A","CD8B","GZMK","NKG7"],
    "Regulatory T cell": ["FOXP3","IL2RA","CTLA4","TIGIT","IKZF2"],
    "NK cell": ["NKG7","GNLY","KLRD1","KLRB1","NCAM1","GZMB","PRF1"],
    "B cell": ["CD79A","CD79B","MS4A1","CD19","PAX5","BANK1"],
    "Plasma cell": ["JCHAIN","MZB1","SDC1","IGHG1","XBP1","PRDM1"],
    "Monocyte": ["CD14","LYZ","S100A9","S100A8","VCAN","FCN1"],
    "Classical monocyte": ["CD14","LYZ","S100A9","S100A8","VCAN"],
    "Non-classical monocyte": ["FCGR3A","MS4A7","LST1","LILRB2","IFITM3"],
    "Macrophage": ["CD68","CD163","MRC1","MSR1","MARCO","LGMN","C1QA"],
    "Dendritic cell": ["FCER1A","CLEC10A","CD1C","HLA-DQA1","ITGAX"],
    "Plasmacytoid dendritic cell": ["CLEC4C","IL3RA","NRP1","IRF7","TCF4"],
    "Mast cell": ["TPSAB1","TPSB2","CPA3","KIT","HPGDS","HDC"],
    "Neutrophil": ["CSF3R","FCGR3B","CXCR2","S100A12","MMP9"],
    "Eosinophil": ["CLC","RNASE2","PRG2","EPX","CCR3"],
    "Basophil": ["CLC","HDC","GATA2","CPA3","MS4A2"],
    "Platelet": ["PF4","PPBP","GP9","ITGA2B","TUBB1"],
    "Erythrocyte": ["HBA1","HBA2","HBB","HBD","ALAS2","SLC4A1"],
    "Erythroid progenitor": ["GYPA","GYPB","KLF1","TFRC","EPOR"],
    "HSC": ["CD34","THY1","KIT","CRHBP","HLF","AVP","MLLT3"],
    "Megakaryocyte": ["PF4","PPBP","GP9","ITGA2B","TUBB1","ITGB3"],
    "Fibroblast": ["DCN","COL1A1","COL1A2","LUM","PDGFRA","THY1"],
    "Myofibroblast": ["ACTA2","TAGLN","MYL9","COL1A1","COL3A1"],
    "Smooth muscle cell": ["ACTA2","MYH11","TAGLN","CNN1","DES"],
    "Endothelial cell": ["PECAM1","VWF","CDH5","ERG","FLT1","KDR"],
    "Lymphatic endothelial cell": ["PROX1","LYVE1","FLT4","PDPN","CCL21"],
    "Epithelial cell": ["EPCAM","KRT18","KRT19","KRT8","CDH1"],
    "Basal cell": ["KRT5","KRT14","TP63","ITGA6","ITGB4"],
    "Alveolar type 1": ["AGER","PDPN","CAV1","EMP2","HOPX"],
    "Alveolar type 2": ["SFTPC","SFTPB","SFTPA1","ABCA3","NAPSA"],
    "Club cell": ["SCGB1A1","SCGB3A1","CYP2F1","BPIFB1"],
    "Ciliated cell": ["FOXJ1","PIFO","TPPP3","SNTN","CAPS"],
    "Goblet cell": ["MUC5AC","MUC5B","SPDEF","AGR2","TFF3"],
    "Hepatocyte": ["ALB","APOB","HP","TF","TTR","PCK1","CYP3A4"],
    "Cholangiocyte": ["KRT19","KRT7","EPCAM","SOX9","SPP1"],
    "Stellate cell": ["RGS5","ACTA2","DES","PDGFRB","LRAT"],
    "Cardiomyocyte": ["TNNT2","MYH7","MYH6","ACTC1","MYL2"],
    "Pericyte": ["RGS5","PDGFRB","NOTCH3","KCNJ8","ABCC9"],
    "Adipocyte": ["ADIPOQ","LEP","PLIN1","FABP4","LPL"],
    "Neuron": ["RBFOX3","MAP2","SYT1","SNAP25","NEFL","NEFM"],
    "Astrocyte": ["GFAP","AQP4","SLC1A3","SLC1A2","ALDH1L1"],
    "Oligodendrocyte": ["MBP","PLP1","MOG","MAG","MOBP"],
    "Microglia": ["CX3CR1","P2RY12","TMEM119","CSF1R","AIF1"],
    "Schwann cell": ["MPZ","PRX","PMP22","SOX10","S100B"],
    "Podocyte": ["NPHS1","NPHS2","PODXL","WT1","SYNPO"],
    "Proximal tubule cell": ["SLC34A1","LRP2","CUBN","SLC22A6","ALDOB"],
    "Melanocyte": ["PMEL","MLANA","TYR","TYRP1","DCT","MITF"],
    "Keratinocyte": ["KRT1","KRT10","KRT14","KRT5","IVL","LOR"],
    "Chondrocyte": ["COL2A1","ACAN","SOX9","COL9A1","COMP"],
    "Osteoblast": ["BGLAP","RUNX2","SP7","COL1A1","ALPL"],
    "Osteoclast": ["ACP5","CTSK","MMP9","OSCAR","DCSTAMP"],
}

def load_marker_db(marker_path=None):
    """Load marker database from JSON file or use built-in defaults."""
    global MARKER_DB
    
    # Try loading full CellMarker2 database
    paths_to_try = []
    if marker_path:
        paths_to_try.append(marker_path)
    # Look next to server script and in working directory
    script_dir = Path(__file__).parent
    paths_to_try.extend([
        script_dir / "cell_markers.json",
        Path("cell_markers.json"),
    ])
    
    for p in paths_to_try:
        if Path(p).exists():
            try:
                with open(p) as f:
                    data = json.load(f)
                # Use the global (cross-tissue) human markers
                if "_global" in data and "Human" in data["_global"]:
                    MARKER_DB = data["_global"]["Human"]
                    print(f"  Loaded CellMarker2 database: {len(MARKER_DB)} cell types from {p}")
                    return
            except Exception as e:
                print(f"  Warning: Failed to load {p}: {e}")
    
    # Fall back to built-in
    MARKER_DB = dict(_BUILTIN_MARKERS)
    print(f"  Using built-in marker database: {len(MARKER_DB)} cell types")
    print(f"  (Run download_markers.py for the full CellMarker2 database)")


def annotate_clusters(top_n=50, test="wilcoxon"):
    """Score clusters against marker database using shared DEG results."""
    from scipy.stats import fisher_exact
    
    if ADATA is None or MARKER_DB is None:
        return {"error": "No data or marker database loaded"}
    
    if not MARKER_DB:
        load_marker_db()
    
    # Check annotation cache
    cache_path = Path(LOADED_PATH).with_suffix(".annot_markers.json") if LOADED_PATH else None
    if cache_path and cache_path.exists():
        try:
            with open(cache_path) as f:
                cached_annot = json.load(f)
            if cached_annot.get("cluster_names") == CLUSTER_NAMES and cached_annot.get("n_cells") == N_CELLS:
                print(f"  Marker annotation loaded from cache")
                cached_annot["cached"] = True
                return cached_annot
        except Exception as e:
            print(f"  Marker annotation cache load failed: {e}")
    
    t0 = time.time()
    ANNOT_STATUS["active"] = True
    ANNOT_STATUS["method"] = "markers"

    # Get shared DEG results (cached if already computed by Claude path)
    cluster_genes, small_clusters = _get_shared_deg(top_n=top_n, test=test)
    
    if not cluster_genes:
        ANNOT_STATUS["active"] = False
        return {"error": "DEG computation failed"}

    # Score against marker database
    n_universe = len(GENE_NAMES_LIST)
    ANNOT_STATUS["step"] = f"Scoring {len(CLUSTER_NAMES)} clusters against {len(MARKER_DB)} signatures..."
    ANNOT_STATUS["pct"] = 70
    
    results = []
    for cid, cname in enumerate(CLUSTER_NAMES):
        if cid % 20 == 0:
            pct = 70 + int(25 * cid / max(1, len(CLUSTER_NAMES)))
            ANNOT_STATUS["pct"] = pct
            ANNOT_STATUS["step"] = f"Scoring cluster {cid+1}/{len(CLUSTER_NAMES)}..."
        
        top_genes_list = cluster_genes.get(cname, [])
        top_genes = set(g.upper() for g in top_genes_list)
        n_cells_cluster = int(np.sum(CLUSTER_IDS == cid))
        
        if not top_genes:
            results.append({
                "cluster_id": cid, "cluster_name": cname,
                "n_cells": n_cells_cluster, "top_genes": [], "predictions": []
            })
            continue
        
        predictions = []
        for cell_type, markers in MARKER_DB.items():
            marker_set = set(m.upper() for m in markers)
            if len(marker_set) < 2:
                continue
            overlap = top_genes & marker_set
            if not overlap:
                continue
            score = len(overlap) / len(marker_set)
            a = len(overlap)
            b = len(marker_set) - a
            c = len(top_genes) - a
            d = n_universe - a - b - c
            _, pval = fisher_exact([[a, b], [c, d]], alternative="greater")
            predictions.append({
                "cell_type": cell_type, "score": round(score, 3),
                "pval": float(f"{pval:.2e}"), "markers_found": sorted(overlap),
                "markers_total": len(marker_set), "n_found": len(overlap)
            })
        
        predictions.sort(key=lambda x: (-x["score"], x["pval"]))
        results.append({
            "cluster_id": cid, "cluster_name": cname,
            "n_cells": n_cells_cluster,
            "top_genes": sorted(top_genes)[:20],
            "predictions": predictions[:10]
        })
    
    elapsed = round(time.time() - t0, 1)
    print(f"  Marker annotation complete ({elapsed}s) — {len(results)} clusters scored")
    ANNOT_STATUS["active"] = False
    ANNOT_STATUS["step"] = ""
    ANNOT_STATUS["pct"] = 0
    
    result = {
        "results": results, "elapsed": elapsed,
        "n_clusters": len(CLUSTER_NAMES), "marker_db_size": len(MARKER_DB),
        "top_n": top_n, "cluster_names": CLUSTER_NAMES, "n_cells": N_CELLS
    }
    
    if cache_path:
        try:
            with open(cache_path, "w") as f:
                json.dump(result, f, separators=(",", ":"))
            print(f"  Marker annotation cached to {cache_path}")
        except Exception as e:
            print(f"  Marker annotation cache save failed: {e}")
    
    return result




# ── LLM-based cell type annotation ──

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# ── Shared DEG cache (used by both marker and LLM annotation) ──
_DEG_CACHE = {"key": None, "cluster_genes": None, "small_clusters": None}
_DEG_LOCK = threading.Lock()

def _get_shared_deg(top_n=50, test="wilcoxon"):
    """Run one-vs-rest DEG and return {cluster_name: [top_genes]} dict.
    
    For large datasets (>50k cells), uses stratified subsampling — marker genes
    are virtually identical whether tested on 50k or 600k cells, but 10-20× faster.
    
    Cached in memory — second call with same dataset+test returns instantly.
    Thread-safe: first caller computes, others wait and get the cache.
    """
    import scanpy as sc
    import scipy.sparse as sp
    from collections import Counter

    DEG_MAX_CELLS = DEG_SETTINGS.get("max_cells", 50000) if DEG_SETTINGS.get("fast", True) else 0

    if ADATA is None:
        return {}, set()

    cache_key = (N_CELLS, len(CLUSTER_NAMES), test, DEG_MAX_CELLS)
    
    with _DEG_LOCK:
        # Cache hit — return immediately
        if _DEG_CACHE["key"] == cache_key and _DEG_CACHE["cluster_genes"] is not None:
            print("  DEG results from memory cache")
            return _DEG_CACHE["cluster_genes"], _DEG_CACHE["small_clusters"]

        t_deg = time.time()
        ANNOT_STATUS["step"] = "Preparing data..."
        ANNOT_STATUS["pct"] = 5

        adata = ADATA
        if "fleek_cluster" not in adata.obs.columns:
            adata.obs["fleek_cluster"] = [CLUSTER_NAMES[cid] for cid in CLUSTER_IDS]

        # Normalize if raw counts
        if sp.issparse(adata.X):
            sample = adata.X[:min(1000, adata.n_obs)].toarray()
        else:
            sample = np.asarray(adata.X[:min(1000, adata.n_obs)])
        is_raw = np.allclose(sample, sample.astype(int)) and sample.max() > 20

        if is_raw:
            ANNOT_STATUS["step"] = "Normalizing raw counts..."
            ANNOT_STATUS["pct"] = 10
            print("  Data appears to be raw counts — normalizing for DEG...")
            adata_work = adata.copy() if not BACKED else adata
            if not BACKED:
                sc.pp.normalize_total(adata_work, target_sum=1e4)
                sc.pp.log1p(adata_work)
        else:
            adata_work = adata

        # Filter out clusters with too few cells
        cluster_counts = Counter(adata_work.obs["fleek_cluster"])
        valid_clusters = {c for c, n in cluster_counts.items() if n >= 5}
        small_clusters = {c for c, n in cluster_counts.items() if n < 5}
        if small_clusters:
            print(f"  Skipping {len(small_clusters)} clusters with <5 cells")

        mask = adata_work.obs["fleek_cluster"].isin(valid_clusters)
        adata_deg = adata_work[mask].copy()

        # Subsample for speed on large datasets
        n_deg = adata_deg.n_obs
        if n_deg > DEG_MAX_CELLS:
            ANNOT_STATUS["step"] = f"Subsampling {DEG_MAX_CELLS:,} / {n_deg:,} cells..."
            ANNOT_STATUS["pct"] = 12
            # Stratified subsample preserving cluster proportions
            rng = np.random.default_rng(42)
            deg_clusters = adata_deg.obs["fleek_cluster"].values
            unique_clusters = np.unique(deg_clusters)
            cluster_indices = {c: np.where(deg_clusters == c)[0] for c in unique_clusters}
            # Allocate proportionally with minimum 5 per cluster
            total_avail = sum(len(v) for v in cluster_indices.values())
            sub_idx = []
            for c in unique_clusters:
                ci = cluster_indices[c]
                n_alloc = max(5, int(len(ci) / total_avail * DEG_MAX_CELLS))
                n_alloc = min(n_alloc, len(ci))
                sub_idx.extend(rng.choice(ci, n_alloc, replace=False).tolist())
            sub_idx = sorted(sub_idx)
            adata_deg = adata_deg[sub_idx].copy()
            print(f"  Subsampled {n_deg:,} → {adata_deg.n_obs:,} cells for DEG (stratified)")
        
        n_valid = len(valid_clusters)
        ANNOT_STATUS["step"] = f"Running DEG ({n_valid} clusters, {adata_deg.n_obs:,} cells)..."
        ANNOT_STATUS["pct"] = 15
        print(f"  Running one-vs-rest {test} for {n_valid} clusters on {adata_deg.n_obs:,} cells...")

        try:
            sc.tl.rank_genes_groups(adata_deg, groupby="fleek_cluster", method=test,
                                    n_genes=top_n, use_raw=False)
        except Exception as e:
            print(f"  rank_genes_groups failed: {e}, retrying with t-test...")
            try:
                sc.tl.rank_genes_groups(adata_deg, groupby="fleek_cluster", method="t-test",
                                        n_genes=top_n, use_raw=False)
            except Exception as e2:
                print(f"  DEG failed: {e2}")
                return {}, small_clusters

        # Extract top genes per cluster
        result = {}
        for cid, cname in enumerate(CLUSTER_NAMES):
            if cname in small_clusters:
                result[cname] = []
                continue
            try:
                names = adata_deg.uns["rank_genes_groups"]["names"][cname][:top_n]
                scores = adata_deg.uns["rank_genes_groups"]["scores"][cname][:top_n]
                genes = [str(g) for g, s in zip(names, scores) if s > 0]
                result[cname] = genes[:top_n]
            except (KeyError, IndexError):
                result[cname] = []

        if adata_deg is not adata_work and adata_deg is not adata:
            del adata_deg
        if adata_work is not adata:
            del adata_work

        elapsed_deg = time.time() - t_deg
        print(f"  Shared DEG complete ({elapsed_deg:.1f}s) — cached for reuse")

        _DEG_CACHE["key"] = cache_key
        _DEG_CACHE["cluster_genes"] = result
        _DEG_CACHE["small_clusters"] = small_clusters

        return result, small_clusters


def annotate_clusters_llm(top_n=30, test="wilcoxon", tissue_hint=""):
    """Use Claude API to infer cell types from top marker genes per cluster.
    Batches clusters into groups to avoid token limits.

    Returns same format as annotate_clusters for UI compatibility.
    """
    import urllib.request
    import urllib.error

    if not ANTHROPIC_API_KEY:
        return {"error": "No API key. Set ANTHROPIC_API_KEY environment variable or pass --api-key."}

    if ADATA is None:
        return {"error": "No dataset loaded"}

    # Check cache
    cache_path = Path(LOADED_PATH).with_suffix(".annot_llm.json") if LOADED_PATH else None
    if cache_path and cache_path.exists():
        try:
            with open(cache_path) as f:
                cached = json.load(f)
            if cached.get("cluster_names") == CLUSTER_NAMES and cached.get("n_cells") == N_CELLS:
                print(f"  LLM annotation loaded from cache")
                cached["cached"] = True
                return cached
        except Exception as e:
            print(f"  LLM annotation cache load failed: {e}")

    t0 = time.time()
    ANNOT_STATUS["active"] = True
    ANNOT_STATUS["method"] = "claude"
    ANNOT_STATUS["step"] = f"Computing top genes ({N_CELLS:,} cells)..."
    ANNOT_STATUS["pct"] = 5

    # Step 1: Get top genes per cluster (shared with marker path)
    print("  LLM annotation: getting shared DEG results...")
    cluster_genes, _ = _get_shared_deg(top_n=50, test=test)

    ANNOT_STATUS["step"] = "Preparing API batches..."
    ANNOT_STATUS["pct"] = 40

    # Step 2: Build cluster info list
    cluster_info = []
    for cid, cname in enumerate(CLUSTER_NAMES):
        genes = cluster_genes.get(cname, [])
        n_cells = int(np.sum(CLUSTER_IDS == cid))
        cluster_info.append({"cid": cid, "cname": cname, "n_cells": n_cells, "genes": genes})

    # Step 3: Batch clusters (~50 per call to stay well within token limits)
    BATCH_SIZE = 50
    all_predictions_raw = []
    total_in_tok = 0
    total_out_tok = 0
    model_name = "claude"
    n_batches = (len(cluster_info) + BATCH_SIZE - 1) // BATCH_SIZE

    tissue_ctx = f" from {tissue_hint} tissue" if tissue_hint else ""

    for batch_idx in range(n_batches):
        batch = cluster_info[batch_idx * BATCH_SIZE : (batch_idx + 1) * BATCH_SIZE]
        cluster_lines = []
        for ci in batch:
            if ci["genes"]:
                cluster_lines.append(f'  Cluster "{ci["cname"]}" ({ci["n_cells"]:,} cells): {", ".join(ci["genes"][:25])}')
            else:
                cluster_lines.append(f'  Cluster "{ci["cname"]}" ({ci["n_cells"]:,} cells): [no significant markers]')

        prompt = f"""You are an expert single-cell RNA-seq bioinformatician. Below are clusters from a scRNA-seq dataset{tissue_ctx} with their top differentially expressed marker genes (one-vs-rest, ranked by significance).

For each cluster, identify the most likely cell type. Return ONLY valid JSON — no markdown, no explanation outside the JSON. Use this exact format:

[
  {{"cluster": "cluster_name", "cell_type": "predicted type", "confidence": "high|medium|low", "reasoning": "brief explanation citing key markers"}},
  ...
]

Clusters and their top marker genes:
{chr(10).join(cluster_lines)}

Respond with ONLY the JSON array. No markdown fences. No other text."""

        pct = 40 + int(50 * batch_idx / max(1, n_batches))
        ANNOT_STATUS["step"] = f"Claude API batch {batch_idx+1}/{n_batches}..."
        ANNOT_STATUS["pct"] = pct
        print(f"  LLM annotation: batch {batch_idx+1}/{n_batches} ({len(batch)} clusters)...")
        request_body = json.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 8192,
            "messages": [{"role": "user", "content": prompt}]
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=request_body,
            headers={
                "Content-Type": "application/json",
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01"
            },
            method="POST"
        )

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                resp_data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            return {"error": f"Claude API error {e.code}: {body[:200]}"}
        except Exception as e:
            return {"error": f"Claude API request failed: {str(e)}"}

        model_name = resp_data.get("model", model_name)
        usage = resp_data.get("usage", {})
        total_in_tok += usage.get("input_tokens", 0)
        total_out_tok += usage.get("output_tokens", 0)

        # Parse response
        text = ""
        for block in resp_data.get("content", []):
            if block.get("type") == "text":
                text += block["text"]

        text = text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3].strip()
        if text.startswith("json"):
            text = text[4:].strip()

        try:
            batch_predictions = json.loads(text)
            all_predictions_raw.extend(batch_predictions)
        except json.JSONDecodeError as e:
            print(f"  Warning: batch {batch_idx+1} JSON parse failed: {e}")
            # Try to salvage partial results
            continue

    # Step 4: Convert to standard format
    results = []
    for ci in cluster_info:
        cid = ci["cid"]
        cname = ci["cname"]

        pred = None
        for p in all_predictions_raw:
            if p.get("cluster") == cname:
                pred = p
                break

        predictions = []
        if pred:
            conf = pred.get("confidence", "medium")
            score = {"high": 0.9, "medium": 0.6, "low": 0.3}.get(conf, 0.5)
            predictions.append({
                "cell_type": pred.get("cell_type", "Unknown"),
                "score": score,
                "confidence": conf,
                "reasoning": pred.get("reasoning", ""),
                "n_found": 0,
                "markers_total": len(ci["genes"]),
                "pval": 0
            })

        results.append({
            "cluster_id": cid,
            "cluster_name": cname,
            "n_cells": ci["n_cells"],
            "top_genes": ci["genes"][:20],
            "predictions": predictions
        })

    elapsed = round(time.time() - t0, 1)
    print(f"  LLM annotation complete ({elapsed}s, {model_name}, {total_in_tok}+{total_out_tok} tokens, {n_batches} batches)")
    ANNOT_STATUS["active"] = False
    ANNOT_STATUS["step"] = ""
    ANNOT_STATUS["pct"] = 0

    result = {
        "results": results,
        "elapsed": elapsed,
        "n_clusters": len(CLUSTER_NAMES),
        "method": "llm",
        "model": model_name,
        "tokens": {"input": total_in_tok, "output": total_out_tok},
        "top_n": top_n,
        "cluster_names": CLUSTER_NAMES,
        "n_cells": N_CELLS
    }

    # Save cache
    if cache_path:
        try:
            with open(cache_path, "w") as f:
                json.dump(result, f, separators=(",", ":"))
            print(f"  LLM annotation cached to {cache_path}")
        except Exception as e:
            print(f"  LLM annotation cache save failed: {e}")

    return result

def _progress(msg, pct=None):
    """Update global progress for client polling. Raises AbortError if abort was requested."""
    PROGRESS["message"] = msg
    if pct is not None:
        PROGRESS["pct"] = pct
    PROGRESS["status"] = "processing"
    print(f"  [{pct or '?'}%] {msg}")
    _check_abort()


def _get_available_ram_gb():
    """Estimate available RAM in GB."""
    try:
        import psutil
        return psutil.virtual_memory().available / 1e9
    except ImportError:
        # Assume 16GB if psutil not available
        return 16.0


class AbortError(Exception):
    pass

def _check_abort():
    """Raise AbortError if abort was requested."""
    if ABORT_REQUESTED:
        raise AbortError("Loading aborted by user")

def _reset_all():
    """Free all data globals and reclaim memory."""
    global ADATA, UMAP_2D, UMAP_3D, PCA_2D, PCA_3D, PACMAP_2D, PACMAP_3D
    global PACMAP_COMPUTING, CLUSTER_IDS, CLUSTER_NAMES, GENE_NAMES_LIST
    global N_CELLS, BACKED, X_CSC, HVG_NAMES, HVG_VAR, ALL_GENE_VAR, GENE_INDEX, CSC_BUILDING
    global CSC_CACHED, CSC_TIME, LOADED_PATH, LOAD_SETTINGS, ABORT_REQUESTED
    ADATA = None
    UMAP_2D = None; UMAP_3D = None
    PCA_2D = None; PCA_3D = None
    PACMAP_2D = None; PACMAP_3D = None
    PACMAP_COMPUTING = False
    CLUSTER_IDS = None; CLUSTER_NAMES = None
    GENE_NAMES_LIST = None; N_CELLS = 0
    BACKED = False; X_CSC = None
    HVG_NAMES = []; HVG_VAR = {}; ALL_GENE_VAR = None; GENE_INDEX = {}
    CSC_BUILDING = False; CSC_CACHED = False; CSC_TIME = 0
    LOADED_PATH = ""; LOAD_SETTINGS.clear()
    ABORT_REQUESTED = False
    # Clear DEG cache
    _DEG_CACHE.clear()
    import gc; gc.collect()

def load_and_prepare(h5ad_path, max_cells=0, n_dims_list=[2, 3], fast_umap=False,
                     fast_umap_subsample=50000, backed="off"):
    """Load h5ad, subsample if needed, compute UMAP(s).
    
    backed: "auto" (use file size vs RAM), "on" (force backed), "off" (force in-memory)
    """
    global ADATA, UMAP_2D, UMAP_3D, PCA_2D, PCA_3D, PACMAP_2D, PACMAP_3D, PACMAP_COMPUTING, CLUSTER_IDS, CLUSTER_NAMES, GENE_NAMES_LIST, N_CELLS, BACKED, X_CSC, HVG_NAMES, HVG_VAR, ALL_GENE_VAR, GENE_INDEX, CSC_BUILDING, CSC_CACHED, CSC_TIME, LOADED_PATH, ABORT_REQUESTED

    import scanpy as sc
    import scipy.sparse as sp
    import gc

    ABORT_REQUESTED = False  # Reset at start of new load

    # Free old dataset before loading new one
    if ADATA is not None:
        _progress("Freeing previous dataset...", 2)
        _reset_all()

    _check_abort()
    _progress("Loading h5ad file...", 5)
    LOADED_PATH = str(h5ad_path)
    t0 = time.time()

    # Decide backed mode
    file_size_gb = os.path.getsize(h5ad_path) / 1e9
    avail_ram_gb = _get_available_ram_gb()
    use_backed = False
    if backed == "on":
        use_backed = True
    elif backed == "auto":
        # Use backed if file is > 40% of available RAM
        use_backed = file_size_gb > avail_ram_gb * 0.4
    # backed == "off" → use_backed stays False

    if use_backed:
        _progress(f"Loading in backed mode ({file_size_gb:.1f}GB file, {avail_ram_gb:.0f}GB RAM avail)...", 5)
        adata = sc.read_h5ad(h5ad_path, backed="r")
        BACKED = True
    else:
        adata = sc.read_h5ad(h5ad_path)
        BACKED = False
    _progress(f"Loaded {adata.n_obs:,} cells x {adata.n_vars:,} genes"
              f" ({'backed' if BACKED else 'in-memory'}, {time.time()-t0:.0f}s)", 10)

    # Subsample
    if max_cells > 0 and adata.n_obs > max_cells:
        _progress(f"Subsampling to {max_cells:,} cells...", 12)
        rng = np.random.default_rng(42)
        idx = rng.choice(adata.n_obs, size=max_cells, replace=False)
        idx.sort()
        if BACKED:
            # Read subset into memory — it's small by definition
            _progress(f"Reading {max_cells:,}-cell subset from disk...", 13)
            adata = adata[idx].to_memory()
            BACKED = False
        else:
            adata = adata[idx].copy()

    N_CELLS = adata.n_obs
    _progress(f"Working with {N_CELLS:,} cells", 15)

    # Load fleek cache (UMAP, PCA, leiden, PaCMAP — all in one file)
    cache_path = Path(h5ad_path).with_suffix(".fleek_cache.npz")
    old_cache = Path(h5ad_path).with_suffix(".umap_cache.npz")
    if not cache_path.exists() and old_cache.exists():
        print(f"  Migrating old cache {old_cache.name} → {cache_path.name}")
        old_cache.rename(cache_path)
    cached = {}
    _cache_time = 0.0  # accumulate time spent loading caches
    _CACHE_SKIP_VALIDATE = {"leiden_names"}  # byte arrays, not cell-indexed
    if cache_path.exists():
        _progress("Checking cache...", 20)
        _ct0 = time.time()
        try:
            cached = dict(np.load(cache_path, allow_pickle=False))
            for k in list(cached.keys()):
                if k in _CACHE_SKIP_VALIDATE:
                    continue
                if cached[k].shape[0] != N_CELLS:
                    _progress("Cache mismatch, will recompute", 20)
                    print(f"  Cache key '{k}' has {cached[k].shape[0]} rows, expected {N_CELLS}")
                    cached = {}
                    break
        except Exception as e:
            _progress(f"Cache load failed, recomputing", 20)
            cached = {}
        _cache_time += time.time() - _ct0

    need_save = False
    neighbors_built = False

    # Cluster IDs from cell_type or leiden
    if "cell_type" in adata.obs.columns:
        cats = adata.obs["cell_type"].astype("category")
        CLUSTER_IDS = cats.cat.codes.to_numpy().astype(np.int32)
        CLUSTER_NAMES = cats.cat.categories.tolist()
    elif "leiden" in adata.obs.columns:
        cats = adata.obs["leiden"].astype("category")
        CLUSTER_IDS = cats.cat.codes.to_numpy().astype(np.int32)
        CLUSTER_NAMES = [f"Cluster {c}" for c in cats.cat.categories]
    elif "leiden_ids" in cached and "leiden_names" in cached:
        # Load cached leiden results
        CLUSTER_IDS = cached["leiden_ids"].astype(np.int32)
        import json as _json
        CLUSTER_NAMES = _json.loads(cached["leiden_names"].tobytes().decode("utf-8"))
        print(f"  Leiden clusters loaded from cache ({len(CLUSTER_NAMES)} clusters)")
    else:
        # Run leiden clustering
        print("  No cell_type or leiden found, computing clusters...")
        _progress("Computing clusters (PCA + neighbors + leiden)...", 15)
        if "neighbors" not in adata.uns or "connectivities" not in adata.obsp:
            _ensure_neighbors(adata)
        _progress("Running leiden clustering...", 18)
        sc.tl.leiden(adata, resolution=1.0, flavor="igraph", n_iterations=2, directed=False)
        cats = adata.obs["leiden"].astype("category")
        CLUSTER_IDS = cats.cat.codes.to_numpy().astype(np.int32)
        CLUSTER_NAMES = [f"Cluster {c}" for c in cats.cat.categories]
        # Cache leiden results
        import json as _json
        cached["leiden_ids"] = CLUSTER_IDS
        cached["leiden_names"] = np.frombuffer(_json.dumps(CLUSTER_NAMES).encode("utf-8"), dtype=np.uint8)
        need_save = True

    # Gene names (use var index, or feature_name if available)
    if "feature_name" in adata.var.columns:
        adata.var.index = adata.var["feature_name"].astype(str).values
        adata.var_names_make_unique()
        GENE_NAMES_LIST = adata.var_names.tolist()
    else:
        adata.var.index = adata.var.index.astype(str)
        adata.var_names_make_unique()
        GENE_NAMES_LIST = adata.var_names.tolist()

    # Compute UMAP(s) — with caching to avoid recomputation

    # Decide if we should use subsample-and-project
    use_fast = fast_umap and N_CELLS > fast_umap_subsample

    # Figure out which dims need computing
    dims_needed = []
    umap_suffix = "_quick" if use_fast else "_full"
    umap_from_cache = True
    for nd in n_dims_list:
        # Check method-specific key first, then legacy key as fallback
        cache_key = f"umap_{nd}d{umap_suffix}"
        legacy_key = f"umap_{nd}d"
        if cache_key in cached:
            _progress(f"Loaded {nd}D UMAP from cache ({'quick' if use_fast else 'full'})", 25)
            if nd == 2:
                UMAP_2D = cached[cache_key].astype(np.float32)
            else:
                UMAP_3D = cached[cache_key].astype(np.float32)
        elif legacy_key in cached:
            _progress(f"Loaded {nd}D UMAP from cache (legacy)", 25)
            if nd == 2:
                UMAP_2D = cached[legacy_key].astype(np.float32)
            else:
                UMAP_3D = cached[legacy_key].astype(np.float32)
        else:
            dims_needed.append(nd)
            umap_from_cache = False

    if dims_needed and use_fast:
        # ── Shared setup: subsample + PCA (done ONCE for all dims) ──
        import umap as umap_lib
        import scipy.sparse as sp

        _progress(f"QuickMap: subsampling {fast_umap_subsample:,} cells...", 28)
        rng = np.random.default_rng(42)
        sub_idx = _stratified_subsample(CLUSTER_IDS, fast_umap_subsample, rng)

        sub_adata = adata[sub_idx]
        if BACKED:
            try:
                sub_adata = sub_adata.to_memory()
            except AttributeError:
                sub_adata = sub_adata.copy()
        else:
            sub_adata = sub_adata.copy()

        _progress(f"QuickMap: PCA on {len(sub_idx):,}-cell subsample...", 30)
        sc.pp.normalize_total(sub_adata, target_sum=1e4)
        sc.pp.log1p(sub_adata)
        sc.pp.highly_variable_genes(sub_adata, n_top_genes=2000)
        sub_adata = sub_adata[:, sub_adata.var.highly_variable].copy()

        # Capture scaling params for batch projection
        X_pre = sub_adata.X.toarray() if sp.issparse(sub_adata.X) else np.asarray(sub_adata.X)
        gene_mean = X_pre.mean(axis=0).astype(np.float64)
        gene_std = X_pre.std(axis=0).astype(np.float64)
        gene_std[gene_std == 0] = 1.0
        hvg_names = sub_adata.var_names.tolist()
        del X_pre

        sc.pp.scale(sub_adata, max_value=10)
        sc.tl.pca(sub_adata, n_comps=30)
        pca_comp = sub_adata.varm["PCs"][:, :30].copy()
        X_sub = sub_adata.obsm["X_pca"][:, :30].copy()
        del sub_adata  # free subsample

        # ── Batch PCA projection for all cells (done ONCE) ──
        if "X_pca" not in adata.obsm:
            _progress(f"QuickMap: projecting {N_CELLS:,} cells to PCA space...", 35)
            hvg_set = set(hvg_names)
            hvg_idx = [i for i, g in enumerate(adata.var_names) if g in hvg_set]

            batch_size = 20000
            all_pca = np.empty((N_CELLS, 30), dtype=np.float32)
            is_sparse = sp.issparse(adata.X)
            for bi in range(0, N_CELLS, batch_size):
                be = min(bi + batch_size, N_CELLS)
                chunk_full = adata.X[bi:be, :]
                if is_sparse:
                    row_sums = np.asarray(chunk_full.sum(axis=1)).ravel()
                else:
                    row_sums = np.asarray(chunk_full).sum(axis=1)
                row_sums[row_sums == 0] = 1
                scale_factors = (1e4 / row_sums).reshape(-1, 1)
                chunk_hvg = chunk_full[:, hvg_idx]
                if is_sparse:
                    chunk_hvg = chunk_hvg.toarray()
                chunk_hvg = np.asarray(chunk_hvg, dtype=np.float64)
                chunk_hvg *= scale_factors
                np.log1p(chunk_hvg, out=chunk_hvg)
                chunk_hvg = (chunk_hvg - gene_mean) / gene_std
                np.clip(chunk_hvg, -10, 10, out=chunk_hvg)
                all_pca[bi:be] = (chunk_hvg @ pca_comp).astype(np.float32)
                if N_CELLS > batch_size:
                    pct = 35 + int((be / N_CELLS) * 10)
                    _progress(f"QuickMap: PCA projected {be:,}/{N_CELLS:,} cells", pct)

            adata.obsm["X_pca"] = all_pca
            del all_pca, pca_comp, gene_mean, gene_std

        X_all = adata.obsm["X_pca"][:, :30]
        sub_set = set(sub_idx.tolist())
        rest_idx = np.array([i for i in range(N_CELLS) if i not in sub_set])

        # ── Per-dimension: fit UMAP + project (only the UMAP differs) ──
        for di, nd in enumerate(dims_needed):
            base_pct = 48 + di * 25
            _progress(f"QuickMap {nd}D: fitting UMAP on {len(sub_idx):,} cells...", base_pct)
            t0 = time.time()

            reducer = umap_lib.UMAP(
                n_components=nd, n_neighbors=15, min_dist=0.3,
                low_memory=True, n_jobs=-1
            )
            emb_sub = reducer.fit_transform(X_sub)
            _progress(f"QuickMap {nd}D: projecting {len(rest_idx):,} remaining cells...", base_pct + 12)

            full_emb = np.empty((N_CELLS, nd), dtype=np.float32)
            full_emb[sub_idx] = emb_sub.astype(np.float32)

            if len(rest_idx) > 0:
                batch_size = 50000
                n_rest = len(rest_idx)
                for bi in range(0, n_rest, batch_size):
                    batch_end = min(bi + batch_size, n_rest)
                    batch_idx = rest_idx[bi:batch_end]
                    emb_batch = reducer.transform(X_all[batch_idx])
                    full_emb[batch_idx] = emb_batch.astype(np.float32)
                    proj_pct = base_pct + 12 + int(batch_end / n_rest * 12)
                    _progress(f"QuickMap {nd}D: projected {batch_end:,}/{n_rest:,} cells", proj_pct)

            elapsed = time.time() - t0
            _progress(f"QuickMap {nd}D complete ({elapsed:.0f}s)", base_pct + 24)

            if nd == 2:
                UMAP_2D = full_emb
            else:
                UMAP_3D = full_emb
            cached[f"umap_{nd}d_quick"] = full_emb
            need_save = True

    elif dims_needed:
        # ── Standard full UMAP ──
        neighbors_built = False
        for di, nd in enumerate(dims_needed):
            base_pct = 30 + di * 30
            if not neighbors_built:
                _progress(f"Building neighbor graph for {N_CELLS:,} cells...", base_pct)
                _ensure_neighbors(adata)
                neighbors_built = True

            _progress(f"Computing {nd}D UMAP for {N_CELLS:,} cells...", base_pct + 10)
            t0 = time.time()
            sc.tl.umap(adata, n_components=nd)
            _progress(f"{nd}D UMAP done ({time.time()-t0:.0f}s)", base_pct + 28)

            umap_arr = adata.obsm["X_umap"].astype(np.float32)
            if nd == 2:
                UMAP_2D = umap_arr
            else:
                UMAP_3D = umap_arr
            cached[f"umap_{nd}d_full"] = umap_arr
            need_save = True

    if need_save:
        # Also save PCA coords to cache if available
        if "X_pca" in adata.obsm:
            pca_arr = adata.obsm["X_pca"].astype(np.float32)
            cached["pca_2d"] = pca_arr[:, :2].copy()
            cached["pca_3d"] = pca_arr[:, :3].copy()
            cached["pca_full"] = pca_arr.copy()
        _progress("Saving UMAP cache...", 95)
        np.savez(cache_path, **cached)

    ADATA = adata

    # ── Extract PCA coordinates ──
    # Priority: cache > obsm > compute
    if "pca_full" in cached:
        pca_full = cached["pca_full"].astype(np.float32)
        PCA_2D = pca_full[:, :2].copy()
        PCA_3D = pca_full[:, :3].copy()
        # Restore to obsm so PaCMAP and other tools can use it
        if "X_pca" not in adata.obsm:
            adata.obsm["X_pca"] = pca_full
        print(f"  PCA loaded from cache ({pca_full.shape[1]} components)")
    elif "pca_2d" in cached and "pca_3d" in cached:
        # Legacy cache with only 2D/3D — use for display but PaCMAP won't work
        PCA_2D = cached["pca_2d"].astype(np.float32)
        PCA_3D = cached["pca_3d"].astype(np.float32)
        print(f"  PCA loaded from cache (2D/3D only, no full PCA for PaCMAP)")
    elif "X_pca" in adata.obsm:
        pca_arr = adata.obsm["X_pca"].astype(np.float32)
        PCA_2D = pca_arr[:, :2].copy()
        PCA_3D = pca_arr[:, :3].copy()
        print(f"  PCA extracted from obsm ({pca_arr.shape[1]} components)")
        # Save full PCA to cache for next time
        cached["pca_2d"] = PCA_2D
        cached["pca_3d"] = PCA_3D
        cached["pca_full"] = pca_arr.copy()
        try:
            np.savez(cache_path, **cached)
        except Exception:
            pass
    else:
        PCA_2D = None
        PCA_3D = None
        print(f"  PCA not available (will compute in background)")
        # Compute in background to avoid blocking load
        def _bg_pca():
            global PCA_2D, PCA_3D
            try:
                import scanpy as sc
                sc.tl.pca(adata, n_comps=min(50, adata.n_vars - 1))
                pca_arr = adata.obsm["X_pca"].astype(np.float32)
                PCA_2D = pca_arr[:, :2].copy()
                PCA_3D = pca_arr[:, :3].copy()
                cached["pca_2d"] = PCA_2D
                cached["pca_3d"] = PCA_3D
                cached["pca_full"] = pca_arr.copy()
                try:
                    np.savez(cache_path, **cached)
                except Exception:
                    pass
                print(f"  PCA computed in background ({pca_arr.shape[1]} components)")
            except Exception as e:
                print(f"  Background PCA failed: {e}")
        threading.Thread(target=_bg_pca, daemon=True).start()

    # ── PaCMAP embedding (background subprocess to avoid numba/threading issues) ──
    _pm_suffix = "_quick" if PACMAP_SETTINGS.get("fast", True) else "_full"
    _pm_key2 = f"pacmap_2d{_pm_suffix}"
    _pm_key3 = f"pacmap_3d{_pm_suffix}"
    if _pm_key2 in cached and _pm_key3 in cached:
        PACMAP_2D = cached[_pm_key2].astype(np.float32)
        PACMAP_3D = cached[_pm_key3].astype(np.float32)
        PACMAP_COMPUTING = False
        print(f"  PaCMAP loaded from cache ({'quick' if _pm_suffix == '_quick' else 'full'})")
    elif "pacmap_2d" in cached and "pacmap_3d" in cached:
        # Legacy cache fallback
        PACMAP_2D = cached["pacmap_2d"].astype(np.float32)
        PACMAP_3D = cached["pacmap_3d"].astype(np.float32)
        PACMAP_COMPUTING = False
        print(f"  PaCMAP loaded from cache (legacy)")
    elif "X_pca" in adata.obsm:
        def _bg_pacmap_subprocess():
            global PACMAP_2D, PACMAP_3D, PACMAP_COMPUTING
            import tempfile, subprocess
            PACMAP_COMPUTING = True
            try:
                # Check if pacmap is installed
                proc_check = subprocess.run(
                    [sys.executable, "-c", "import pacmap"],
                    capture_output=True, timeout=10
                )
                if proc_check.returncode != 0:
                    print("  PaCMAP not installed (pip install pacmap)")
                    PACMAP_COMPUTING = False
                    return

                pca_input = adata.obsm["X_pca"][:, :30].astype(np.float32)
                n_total = pca_input.shape[0]
                PACMAP_SUBSAMPLE = PACMAP_SETTINGS.get("max_cells", 50000) if PACMAP_SETTINGS.get("fast", True) else 0

                with tempfile.TemporaryDirectory() as tmpdir:
                    input_path = os.path.join(tmpdir, "pca_in.npy")
                    out2_path = os.path.join(tmpdir, "pacmap_2d.npy")
                    out3_path = os.path.join(tmpdir, "pacmap_3d.npy")
                    np.save(input_path, pca_input)

                    if PACMAP_SUBSAMPLE > 0 and n_total > PACMAP_SUBSAMPLE:
                        # Stratified subsample + nearest-neighbor projection
                        sub_idx = _stratified_subsample(CLUSTER_IDS, PACMAP_SUBSAMPLE,
                                                        np.random.default_rng(42))
                        sub_path = os.path.join(tmpdir, "sub_idx.npy")
                        np.save(sub_path, np.array(sub_idx, dtype=np.int32))

                        script = f'''
import numpy as np, pacmap, time
from scipy.spatial import cKDTree
X = np.load("{input_path}")
sub_idx = np.load("{sub_path}")
X_sub = X[sub_idx]
nn = min(10, max(2, len(sub_idx) // 50))
t0 = time.time()
n_total = X.shape[0]
n_sub = len(sub_idx)
print(f"  PaCMAP 2D ({{n_sub:,}} / {{n_total:,}} cells, {{nn}} neighbors)...")
pm2 = pacmap.PaCMAP(n_components=2, n_neighbors=nn, verbose=False)
Y2_sub = pm2.fit_transform(X_sub).astype(np.float32)
print(f"  PaCMAP 3D...")
pm3 = pacmap.PaCMAP(n_components=3, n_neighbors=nn, verbose=False)
Y3_sub = pm3.fit_transform(X_sub).astype(np.float32)
# Project remaining cells via k-NN weighted interpolation in PCA space
print(f"  Projecting {{n_total - n_sub:,}} remaining cells (k=5 weighted)...")
tree = cKDTree(X_sub)
rest_mask = np.ones(n_total, dtype=bool)
rest_mask[sub_idx] = False
rest_idx = np.where(rest_mask)[0]
dists, knn_idx = tree.query(X[rest_idx], k=5)
# Inverse-distance weights (add small epsilon to avoid division by zero)
weights = 1.0 / (dists + 1e-10)
weights /= weights.sum(axis=1, keepdims=True)
Y2 = np.empty((n_total, 2), dtype=np.float32)
Y3 = np.empty((n_total, 3), dtype=np.float32)
Y2[sub_idx] = Y2_sub
Y3[sub_idx] = Y3_sub
Y2[rest_idx] = np.einsum("nk,nkd->nd", weights, Y2_sub[knn_idx]).astype(np.float32)
Y3[rest_idx] = np.einsum("nk,nkd->nd", weights, Y3_sub[knn_idx]).astype(np.float32)
np.save("{out2_path}", Y2)
np.save("{out3_path}", Y3)
print(f"  PaCMAP done ({{time.time()-t0:.1f}}s, {{n_sub:,}}-cell fit)")
'''
                    else:
                        script = f'''
import numpy as np, pacmap, time
X = np.load("{input_path}")
nn = min(10, max(2, X.shape[0] // 50))
t0 = time.time()
print(f"  PaCMAP 2D ({{X.shape[0]:,}} cells, {{nn}} neighbors)...")
Y2 = pacmap.PaCMAP(n_components=2, n_neighbors=nn, verbose=False).fit_transform(X).astype(np.float32)
np.save("{out2_path}", Y2)
print(f"  PaCMAP 3D...")
Y3 = pacmap.PaCMAP(n_components=3, n_neighbors=nn, verbose=False).fit_transform(X).astype(np.float32)
np.save("{out3_path}", Y3)
print(f"  PaCMAP done ({{time.time()-t0:.1f}}s)")
'''
                    sub_label = f" (subsample {PACMAP_SUBSAMPLE:,})" if PACMAP_SUBSAMPLE > 0 and n_total > PACMAP_SUBSAMPLE else ""
                    print(f"  Computing PaCMAP in background subprocess ({N_CELLS:,} cells{sub_label})...")
                    proc = subprocess.run(
                        [sys.executable, "-c", script],
                        capture_output=True, text=True
                    )
                    if proc.stdout:
                        for line in proc.stdout.strip().split("\n"):
                            print(line)
                    if proc.returncode != 0:
                        stderr = (proc.stderr or "").strip()[-300:]
                        print(f"  PaCMAP subprocess failed (exit {proc.returncode}): {stderr}")
                        PACMAP_COMPUTING = False
                        return

                    PACMAP_2D = np.load(out2_path)
                    PACMAP_3D = np.load(out3_path)

                # Save to cache with method-specific keys
                cached[f"pacmap_2d{_pm_suffix}"] = PACMAP_2D
                cached[f"pacmap_3d{_pm_suffix}"] = PACMAP_3D
                try:
                    np.savez(cache_path, **cached)
                    print(f"  PaCMAP cached")
                except Exception:
                    pass
            except Exception as e:
                print(f"  PaCMAP background compute failed: {e}")
            finally:
                PACMAP_COMPUTING = False
        threading.Thread(target=_bg_pacmap_subprocess, daemon=True).start()
    else:
        PACMAP_2D = None
        PACMAP_3D = None
        PACMAP_COMPUTING = False

    # Build fast lookup structures
    GENE_INDEX = {g: i for i, g in enumerate(ADATA.var_names)}

    # Detect HVG names (instant if pre-annotated, fast subsample if not)
    # Used for UI chips only — gene lookups use full CSC once built
    HVG_NAMES = []
    HVG_VAR = {}
    ALL_GENE_VAR = None
    _has_hvg_col = "highly_variable" in ADATA.var.columns
    if _has_hvg_col:
        hvg_mask = ADATA.var["highly_variable"].values.astype(bool)
        HVG_NAMES = [str(ADATA.var_names[i]) for i in np.where(hvg_mask)[0]]
        # Try to get dispersion/variance from adata.var (for ALL genes, not just HVGs)
        _var_col = None
        for vcol in ["dispersions_norm", "dispersions", "variances_norm", "variances"]:
            if vcol in ADATA.var.columns:
                _var_col = vcol
                vals = ADATA.var[vcol].values
                ALL_GENE_VAR = np.asarray(vals, dtype=np.float32)
                for i in np.where(hvg_mask)[0]:
                    HVG_VAR[str(ADATA.var_names[i])] = float(vals[i])
                print(f"  Found {len(HVG_NAMES):,} pre-annotated HVGs (variability from '{vcol}', all {len(vals):,} genes)")
                HVG_NAMES.sort(key=lambda g: HVG_VAR.get(g, 0), reverse=True)
                break
        else:
            print(f"  Found {len(HVG_NAMES):,} pre-annotated HVGs (no variability column)")

    if not BACKED and sp.issparse(ADATA.X):
        CSC_BUILDING = True
        csc_cache_path = Path(h5ad_path).with_suffix(".csc_cache.npz")
        def _build_gene_index():
            global HVG_NAMES, HVG_VAR, ALL_GENE_VAR, X_CSC, CSC_BUILDING, CSC_CACHED, CSC_TIME
            _csc_t0 = time.time()

            # Compute HVGs by variance if not pre-annotated (subsample for speed)
            if not _has_hvg_col:
                print("  Computing top variable genes...")
                t0 = time.time()
                import scipy.sparse as _sp
                X = ADATA.X
                n_sub = min(50000, X.shape[0])
                if n_sub < X.shape[0]:
                    rng = np.random.default_rng(42)
                    X_sub = X[rng.choice(X.shape[0], n_sub, replace=False)]
                else:
                    X_sub = X
                if _sp.issparse(X_sub):
                    mean = np.asarray(X_sub.mean(axis=0)).ravel()
                    sq_mean = np.asarray(X_sub.multiply(X_sub).mean(axis=0)).ravel()
                    var = sq_mean - mean ** 2
                else:
                    var = np.var(np.asarray(X_sub), axis=0)
                del X_sub
                # Store variance for ALL genes
                ALL_GENE_VAR = var.astype(np.float32)
                n_hvg = min(2000, len(var))
                hvg_idx = np.argsort(var)[-n_hvg:][::-1]
                HVG_NAMES = [str(ADATA.var_names[i]) for i in hvg_idx]
                HVG_VAR = {str(ADATA.var_names[i]): float(var[i]) for i in hvg_idx}
                print(f"  Computed top {n_hvg:,} variable genes ({time.time()-t0:.1f}s, {n_sub:,}-cell subsample)")

            # Try loading CSC from cache
            import scipy.sparse as _sp
            loaded_from_cache = False
            if csc_cache_path.exists():
                print("  Loading cached CSC index...")
                try:
                    t1 = time.time()
                    X_CSC = _sp.load_npz(str(csc_cache_path))
                    if X_CSC.shape != ADATA.X.shape:
                        print(f"  CSC cache shape mismatch ({X_CSC.shape} vs {ADATA.X.shape}), rebuilding...")
                        X_CSC = None
                    else:
                        loaded_from_cache = True
                        CSC_CACHED = True
                        print(f"  CSC index loaded from cache ({time.time()-t1:.1f}s)")
                except Exception as e:
                    print(f"  CSC cache load failed ({e}), rebuilding...")
                    X_CSC = None

            if not loaded_from_cache:
                # Build full CSC — single pass, no intermediate copies
                print("  Building CSC column index...")
                t1 = time.time()
                X_CSC = ADATA.X.tocsc()
                elapsed = time.time() - t1
                print(f"  CSC index ready ({elapsed:.0f}s) — all gene lookups now fast")
                # Save to cache
                try:
                    _sp.save_npz(str(csc_cache_path), X_CSC, compressed=False)
                    cache_mb = os.path.getsize(str(csc_cache_path)) / 1e6
                    print(f"  CSC cache saved ({cache_mb:.0f} MB)")
                except Exception as e:
                    print(f"  CSC cache save failed ({e}) — will rebuild next time")

            CSC_TIME = round(time.time() - _csc_t0, 1)
            CSC_BUILDING = False
        threading.Thread(target=_build_gene_index, daemon=True).start()
    else:
        X_CSC = None
        CSC_BUILDING = False

    # Record load settings for the client
    load_elapsed = time.time() - t0
    pacmap_suffix = "_quick" if PACMAP_SETTINGS.get("fast", True) else "_full"
    LOAD_SETTINGS.clear()
    LOAD_SETTINGS["backed"] = BACKED
    LOAD_SETTINGS["quickmap"] = use_fast
    LOAD_SETTINGS["quickmap_n"] = fast_umap_subsample if use_fast else 0
    LOAD_SETTINGS["quickdeg"] = DEG_SETTINGS.get("fast", True)
    LOAD_SETTINGS["quickdeg_n"] = DEG_SETTINGS.get("max_cells", 50000) if DEG_SETTINGS.get("fast", True) else 0
    LOAD_SETTINGS["quickpacmap"] = PACMAP_SETTINGS.get("fast", True)
    LOAD_SETTINGS["umap_cached"] = umap_from_cache
    LOAD_SETTINGS["umap_method"] = "quick" if use_fast else "full"
    LOAD_SETTINGS["pca_cached"] = ("pca_full" in cached or "pca_2d" in cached)
    LOAD_SETTINGS["leiden_cached"] = ("leiden_ids" in cached)
    LOAD_SETTINGS["pacmap_cached"] = (f"pacmap_2d{pacmap_suffix}" in cached or "pacmap_2d" in cached)
    LOAD_SETTINGS["csc_cached"] = CSC_CACHED
    LOAD_SETTINGS["load_time"] = round(load_elapsed, 1)
    LOAD_SETTINGS["cache_time"] = round(_cache_time, 2)
    # Check annotation caches
    for key, suffix in [("annot_markers_cached", ".annot_markers.json"), ("annot_llm_cached", ".annot_llm.json")]:
        ap = Path(h5ad_path).with_suffix(suffix)
        LOAD_SETTINGS[key] = ap.exists()

    # Load marker database for cell type annotation
    load_marker_db()

    PROGRESS["status"] = "done"
    PROGRESS["pct"] = 100
    PROGRESS["message"] = f"Ready: {N_CELLS:,} cells, {len(CLUSTER_NAMES)} types, {len(GENE_NAMES_LIST):,} genes"
    print(f"  Ready: {N_CELLS:,} cells, {len(CLUSTER_NAMES)} types, {len(GENE_NAMES_LIST):,} genes")


def _stratified_subsample(cluster_ids, n_target, rng):
    """Stratified subsample preserving cluster proportions, with minimum per cluster."""
    unique = np.unique(cluster_ids)
    n_total = len(cluster_ids)
    indices = []
    min_per_cluster = max(5, n_target // (len(unique) * 4))  # floor per cluster

    for cid in unique:
        mask = np.where(cluster_ids == cid)[0]
        # Proportional share
        share = max(min_per_cluster, int(round(len(mask) / n_total * n_target)))
        share = min(share, len(mask))  # can't take more than exist
        chosen = rng.choice(mask, size=share, replace=False)
        indices.append(chosen)

    result = np.concatenate(indices)
    # If we overshot, trim randomly
    if len(result) > n_target * 1.2:
        result = rng.choice(result, size=n_target, replace=False)
    result.sort()
    return result


def _ensure_neighbors(adata):
    """Build neighbor graph if missing."""
    import scanpy as sc

    has_conn = "connectivities" in adata.obsp
    has_uns = "neighbors" in adata.uns

    if has_conn and has_uns:
        return

    # If we have connectivities but no uns metadata, synthesize it
    if has_conn and not has_uns:
        adata.uns["neighbors"] = {"connectivities_key": "connectivities", "distances_key": "distances",
                                  "params": {"n_neighbors": 15, "method": "umap"}}
        print("    Synthesized missing neighbors metadata from existing connectivities")
        return

    if "scvi" in adata.obsm:
        emb = adata.obsm["scvi"]
        nan_mask = np.isnan(emb).any(axis=1)
        if nan_mask.sum() > 0:
            print(f"    Removing {nan_mask.sum()} NaN embedding cells")
            # Can't easily remove in place, just zero them
            emb[nan_mask] = 0
        print("    Building neighbors from scVI embedding...")
        sc.pp.neighbors(adata, use_rep="scvi", n_neighbors=15)
    elif "X_pca" in adata.obsm:
        print("    Building neighbors from existing PCA...")
        sc.pp.neighbors(adata, n_pcs=50, n_neighbors=15)
    else:
        print("    Running PCA + neighbors from scratch...")
        tmp = adata.copy()
        sc.pp.normalize_total(tmp, target_sum=1e4)
        sc.pp.log1p(tmp)
        # Use cell_ranger flavor — doesn't require skmisc
        sc.pp.highly_variable_genes(tmp, n_top_genes=2000)
        tmp = tmp[:, tmp.var.highly_variable].copy()
        sc.pp.scale(tmp, max_value=10)
        sc.tl.pca(tmp, n_comps=50)
        sc.pp.neighbors(tmp, n_pcs=50, n_neighbors=15)
        adata.obsp["distances"] = tmp.obsp["distances"]
        adata.obsp["connectivities"] = tmp.obsp["connectivities"]
        adata.uns["neighbors"] = tmp.uns["neighbors"]


def get_gene_expression(gene_name):
    """Get normalized 0-1 expression for a single gene."""
    import scipy.sparse as sp

    idx = GENE_INDEX.get(gene_name)
    if idx is None:
        return None

    if X_CSC is not None:
        # Fast path: full CSC column slice — O(nnz in column)
        col = X_CSC[:, idx].toarray().ravel().astype(np.float32)
    elif BACKED:
        # Backed mode: read in row batches
        n = ADATA.n_obs
        col = np.empty(n, dtype=np.float32)
        batch = 50000
        for bi in range(0, n, batch):
            be = min(bi + batch, n)
            chunk = ADATA.X[bi:be, idx]
            if sp.issparse(chunk):
                chunk = chunk.toarray().ravel()
            else:
                chunk = np.asarray(chunk).ravel()
            col[bi:be] = chunk
    else:
        # Dense or fallback
        col = ADATA.X[:, idx]
        if sp.issparse(col):
            col = col.toarray().ravel()
        else:
            col = np.asarray(col).ravel()
        col = col.astype(np.float32)

    # Normalize to 0-1
    pos = col[col > 0]
    if len(pos) > 10:
        pmax = np.percentile(pos, 98)
    else:
        pmax = col.max()
    if pmax > 0:
        col = np.clip(col / pmax, 0, 1)
    return col


def build_init_payload():
    """Build the initial binary payload with coords + clusters."""
    parts = []

    avail = []
    if UMAP_2D is not None:
        avail.append(2)
    if UMAP_3D is not None:
        avail.append(3)

    # Build embedding manifest: {method: [dims]}
    emb_manifest = {}
    emb_manifest["umap"] = list(avail)
    pca_dims = []
    if PCA_2D is not None:
        pca_dims.append(2)
    if PCA_3D is not None:
        pca_dims.append(3)
    if pca_dims:
        emb_manifest["pca"] = pca_dims

    pacmap_dims = []
    if PACMAP_2D is not None:
        pacmap_dims.append(2)
    if PACMAP_3D is not None:
        pacmap_dims.append(3)
    if pacmap_dims:
        emb_manifest["pacmap"] = pacmap_dims

    header = {
        "version": 4,
        "n_cells": N_CELLS,
        "n_dims": max(avail) if avail else 2,
        "available_dims": avail,
        "available_embeddings": emb_manifest,
        "n_genes": 0,  # genes loaded on demand
        "n_clusters": len(CLUSTER_NAMES),
        "gene_names": GENE_NAMES_LIST[:500],  # send first 500 for search
        "total_genes": len(GENE_NAMES_LIST),
        "cluster_names": CLUSTER_NAMES,
        "metadata_columns": {},
        "load_settings": dict(LOAD_SETTINGS),
        "loaded_path": LOADED_PATH,
        "hvg_genes": HVG_NAMES[:200],  # top HVGs for quick-access UI
        "hvg_var": {g: round(HVG_VAR[g], 4) for g in HVG_NAMES[:200] if g in HVG_VAR},
    }

    # Include cached annotations if available
    for annot_key, suffix in [("cached_markers", ".annot_markers.json"), ("cached_llm", ".annot_llm.json")]:
        if LOADED_PATH:
            ap = Path(LOADED_PATH).with_suffix(suffix)
            if ap.exists():
                try:
                    with open(ap) as f:
                        cached = json.load(f)
                    if cached.get("cluster_names") == CLUSTER_NAMES and cached.get("n_cells") == N_CELLS:
                        header[annot_key] = cached.get("results", [])
                except Exception:
                    pass

    # Include cached lineage tree if available
    if LOADED_PATH:
        lp = Path(LOADED_PATH).with_suffix(".annot_lineage.json")
        if lp.exists():
            try:
                with open(lp) as f:
                    lcached = json.load(f)
                if lcached.get("cluster_names") == CLUSTER_NAMES and lcached.get("n_cells") == N_CELLS:
                    header["cached_lineage"] = lcached.get("tree")
            except Exception:
                pass

    header_bytes = json.dumps(header, separators=(",", ":")).encode("utf-8")

    buf = io.BytesIO()
    buf.write(b"SCRN")
    # Pad header to 4-byte alignment
    while len(header_bytes) % 4 != 0:
        header_bytes += b" "
    buf.write(struct.pack("<I", len(header_bytes)))
    buf.write(header_bytes)

    # Write embeddings in manifest order: umap first, then pca, etc.
    _emb_arrays = {
        "umap": {2: UMAP_2D, 3: UMAP_3D},
        "pca": {2: PCA_2D, 3: PCA_3D},
        "pacmap": {2: PACMAP_2D, 3: PACMAP_3D},
    }
    for method, dims in emb_manifest.items():
        for nd in dims:
            arr = _emb_arrays.get(method, {}).get(nd)
            if arr is not None:
                for d in range(nd):
                    buf.write(arr[:, d].astype(np.float32).tobytes())

    buf.write(CLUSTER_IDS.tobytes())

    return buf.getvalue()


def run_deg(group_a, group_b, test="wilcoxon"):
    """Run DEG between two cell groups with Cohen's d.
    
    Speed optimization: filters to genes expressed in >=3 cells across both
    groups before testing.  On a 60k-gene dataset this typically reduces the
    test set to 10–20k genes → 3–6× faster.
    """
    import scanpy as sc
    import scipy.sparse as sp

    MIN_CELLS_EXPR = 3  # gene must be nonzero in >=3 cells to be tested

    t0 = time.time()
    indices_a = list(group_a)
    indices_b = list(group_b)
    indices = indices_a + indices_b
    labels = ["A"] * len(indices_a) + ["B"] * len(indices_b)

    sub = ADATA[indices]
    if BACKED:
        try:
            sub = sub.to_memory()
        except AttributeError:
            sub = sub.copy()
    else:
        sub = sub.copy()
    sub.obs["deg_group"] = labels

    # Normalize if raw counts
    sample = sub.X[:min(100, sub.n_obs), :min(100, sub.n_vars)]
    if sp.issparse(sample):
        sample = sample.toarray()
    sample = np.asarray(sample)
    is_raw = np.allclose(sample, sample.astype(int)) and sample.max() > 5
    if is_raw:
        sc.pp.normalize_total(sub, target_sum=1e4)
        sc.pp.log1p(sub)

    # ── Filter to expressed genes (big speedup) ──
    n_all_orig = sub.n_vars
    if sp.issparse(sub.X):
        nnz = np.asarray((sub.X != 0).sum(axis=0)).ravel()
    else:
        nnz = np.asarray((np.asarray(sub.X) != 0).sum(axis=0)).ravel()
    keep_mask = nnz >= MIN_CELLS_EXPR
    n_kept = int(keep_mask.sum())
    if n_kept < n_all_orig and n_kept > 0:
        sub = sub[:, keep_mask].copy()
        print(f"  DEG: filtered {n_all_orig:,} → {n_kept:,} expressed genes")

    t_prep = time.time() - t0

    method = "wilcoxon" if test == "wilcoxon" else "t-test"
    n_all = sub.n_vars
    na, nb = len(indices_a), len(indices_b)
    print(f"  DEG: testing {n_all:,} genes, {na} vs {nb} cells, "
          f"{method}... (prep {t_prep:.1f}s)")
    sc.tl.rank_genes_groups(sub, groupby="deg_group", groups=["A"],
                            reference="B", method=method, n_genes=n_all)

    result = sub.uns["rank_genes_groups"]
    names = [str(x) for x in result["names"]["A"]]
    logfc = [float(x) for x in result["logfoldchanges"]["A"]]
    pvals = [float(x) for x in result["pvals"]["A"]]
    padj = [float(x) for x in result["pvals_adj"]["A"]]

    # Cohen's d — computed on sparse directly, no densification
    print(f"  DEG: computing Cohen's d...")
    X_a = sub.X[:na]
    X_b = sub.X[na:]
    if sp.issparse(X_a):
        mean_a = np.asarray(X_a.mean(axis=0)).ravel()
        mean_b = np.asarray(X_b.mean(axis=0)).ravel()
        sq_a = X_a.multiply(X_a)
        sq_b = X_b.multiply(X_b)
        var_a = np.asarray(sq_a.mean(axis=0)).ravel() - mean_a**2
        var_b = np.asarray(sq_b.mean(axis=0)).ravel() - mean_b**2
        if na > 1: var_a *= na / (na - 1)
        if nb > 1: var_b *= nb / (nb - 1)
        del sq_a, sq_b
    else:
        X_a = np.asarray(X_a, dtype=np.float64)
        X_b = np.asarray(X_b, dtype=np.float64)
        mean_a = X_a.mean(axis=0)
        mean_b = X_b.mean(axis=0)
        var_a = X_a.var(axis=0, ddof=1) if na > 1 else np.zeros(n_all)
        var_b = X_b.var(axis=0, ddof=1) if nb > 1 else np.zeros(n_all)
    pooled_sd = np.sqrt(((na - 1) * var_a + (nb - 1) * var_b) / max(na + nb - 2, 1))
    cohens_d_all = np.where(pooled_sd > 0, (mean_a - mean_b) / pooled_sd, 0.0)

    gene_to_varidx = {str(g): i for i, g in enumerate(sub.var_names)}

    clean = []
    for i in range(len(names)):
        fc = logfc[i]
        p = padj[i]
        if not (np.isfinite(fc) and np.isfinite(p) and p > 0):
            continue
        vidx = gene_to_varidx.get(names[i])
        cd = float(cohens_d_all[vidx]) if vidx is not None else 0.0
        if not np.isfinite(cd):
            cd = 0.0
        clean.append({"gene": names[i], "log2fc": round(fc, 4),
                      "cohens_d": round(cd, 4), "pval": pvals[i], "padj": p})

    clean.sort(key=lambda x: x["padj"])
    elapsed = time.time() - t0
    n_sig = sum(1 for g in clean if abs(g["log2fc"]) >= 0.5 and g["padj"] < 0.05)
    n_filt_note = f" (filtered from {n_all_orig:,})" if n_kept < n_all_orig else ""
    print(f"  DEG: done in {elapsed:.1f}s — {len(clean):,} genes{n_filt_note}, {n_sig:,} significant")

    return {
        "genes": clean, "test": method, "n_a": na, "n_b": nb,
        "n_total_genes": n_all, "n_total_genes_unfiltered": n_all_orig,
        "elapsed": round(elapsed, 1),
        "note": "P-values from single-sample comparison — pseudoreplication caveat applies."
    }


def export_h5ad_subset(cell_indices, group_name):
    """Export a subset of cells as h5ad, return file path."""
    import tempfile
    sub = ADATA[cell_indices]
    if BACKED:
        try:
            sub = sub.to_memory()
        except AttributeError:
            sub = sub.copy()
    else:
        sub = sub.copy()
    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in group_name)
    fname = f"subset_{safe_name}_{len(cell_indices)}cells.h5ad"
    fpath = os.path.join(tempfile.gettempdir(), fname)
    sub.write_h5ad(fpath)
    print(f"  Export: {len(cell_indices)} cells -> {fpath}")
    return fpath, fname



# ─── HTTP Server ───

class FleekHandler(SimpleHTTPRequestHandler):
    """Serves the visualizer HTML and API endpoints."""

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            self._serve_html()
        elif path == "/api/init":
            self._serve_init()
        elif path == "/api/gene":
            gene = params.get("name", [""])[0]
            self._serve_gene(gene)
        elif path == "/api/search":
            q = params.get("q", [""])[0]
            self._serve_search(q)
        elif path == "/api/progress":
            self._serve_progress()
        elif path == "/api/embedding":
            self._serve_embedding(params.get("method", [""])[0])
        elif path == "/api/browse":
            self._serve_browse(params.get("path", [""])[0])
        elif path == "/api/complete":
            self._serve_complete(params.get("partial", [""])[0])
        elif path == "/api/gene-var":
            self._serve_gene_var()
        else:
            self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/upload":
            self._serve_upload()
            return
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        req = json.loads(body)
        if path == "/api/deg":
            self._serve_deg(req)
        elif path == "/api/export":
            self._serve_export(req)
        elif path == "/api/load":
            self._serve_load(req)
        elif path == "/api/annotate":
            self._serve_annotate(req)
        elif path == "/api/annotate-llm":
            self._serve_annotate_llm(req)
        elif path == "/api/compute-embedding":
            self._serve_compute_embedding(req)
        elif path == "/api/abort":
            self._serve_abort(req)
        elif path == "/api/unload":
            self._serve_unload(req)
        elif path == "/api/lineage":
            self._serve_lineage(req)
        else:
            self.send_error(404)

    def _serve_html(self):
        html_path = Path(__file__).parent / "fleek.html"
        if not html_path.exists():
            self.send_error(500, "fleek.html not found next to server script")
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.end_headers()
        self.wfile.write(html_path.read_bytes())

    def _serve_init(self):
        if ADATA is None:
            resp = json.dumps({"no_data": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)
            return
        data = build_init_payload()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def _serve_gene(self, gene_name):
        if ADATA is None:
            self.send_error(503, "No dataset loaded");return
        expr = get_gene_expression(gene_name)
        if expr is None:
            self.send_error(404, f"Gene '{gene_name}' not found")
            return
        data = expr.tobytes()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_embedding(self, method):
        """Return embedding coordinates as binary float32."""
        _emb_arrays = {
            "umap": {2: UMAP_2D, 3: UMAP_3D},
            "pca": {2: PCA_2D, 3: PCA_3D},
            "pacmap": {2: PACMAP_2D, 3: PACMAP_3D},
        }
        emb = _emb_arrays.get(method)
        if not emb:
            err = json.dumps({"error": f"Unknown method: {method}"}).encode()
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)
            return
        dims = []
        if emb.get(2) is not None: dims.append(2)
        if emb.get(3) is not None: dims.append(3)
        if not dims:
            err = json.dumps({"error": f"{method} not computed yet"}).encode()
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)
            return
        # Binary format: 4-byte header_len, JSON header, then float32 arrays
        header = {"method": method, "dims": dims, "n_cells": N_CELLS}
        header_bytes = json.dumps(header, separators=(",", ":")).encode()
        while len(header_bytes) % 4 != 0:
            header_bytes += b" "
        buf = io.BytesIO()
        buf.write(struct.pack("<I", len(header_bytes)))
        buf.write(header_bytes)
        for nd in dims:
            arr = emb[nd]
            for d in range(nd):
                buf.write(arr[:, d].astype(np.float32).tobytes())
        data = buf.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_browse(self, req_path):
        """List directories and h5ad files for the file browser."""
        try:
            # Default to directory of loaded file, or cwd
            if not req_path:
                if LOADED_PATH:
                    req_path = str(Path(LOADED_PATH).parent)
                else:
                    req_path = os.getcwd()
            elif req_path == "~":
                req_path = str(Path.home())

            p = Path(req_path).expanduser().resolve()
            if not p.is_dir():
                p = p.parent

            entries = []
            # Parent directory link
            parent = str(p.parent)
            if parent != str(p):  # not at root
                entries.append({"name": "..", "type": "dir", "path": parent})

            try:
                items = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
            except PermissionError:
                items = []

            for item in items:
                if item.name.startswith("."):
                    continue  # skip hidden files
                if item.is_dir():
                    entries.append({"name": item.name, "type": "dir", "path": str(item)})
                elif item.suffix == ".h5ad":
                    size_mb = round(item.stat().st_size / 1e6, 1)  # decimal MB (matches macOS)
                    cache_path = item.with_suffix(".fleek_cache.npz")
                    csc_path = item.with_suffix(".csc_cache.npz")
                    annot_m = item.with_suffix(".annot_markers.json")
                    annot_l = item.with_suffix(".annot_llm.json")
                    caches = []
                    if cache_path.exists(): caches.append("fleek")
                    if csc_path.exists(): caches.append("csc")
                    if annot_m.exists(): caches.append("markers")
                    if annot_l.exists(): caches.append("claude")
                    annot_lin = item.with_suffix(".annot_lineage.json")
                    if annot_lin.exists(): caches.append("lineage")
                    is_loaded = (LOADED_PATH and str(item.resolve()) == str(Path(LOADED_PATH).resolve()))
                    entries.append({
                        "name": item.name, "type": "h5ad", "path": str(item),
                        "size_mb": size_mb, "caches": caches, "loaded": is_loaded
                    })

            result = {"path": str(p), "entries": entries}
            data = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_complete(self, partial):
        """Return path completions for the browse path input."""
        try:
            if not partial:
                data = json.dumps({"completions": []}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return

            p = Path(partial).expanduser()
            # If partial ends with /, complete children of that directory
            if partial.endswith("/") or partial.endswith(os.sep):
                parent = p
                prefix = ""
            else:
                parent = p.parent
                prefix = p.name  # case-sensitive on Unix

            completions = []
            if parent.is_dir():
                try:
                    for item in sorted(parent.iterdir(), key=lambda x: x.name):
                        if item.name.startswith("."):
                            continue
                        if prefix and not item.name.startswith(prefix):
                            continue
                        if item.is_dir():
                            completions.append(str(item) + "/")
                        elif item.suffix == ".h5ad":
                            completions.append(str(item))
                        if len(completions) >= 15:
                            break
                except PermissionError:
                    pass

            data = json.dumps({"completions": completions}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            err = json.dumps({"completions": []}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_progress(self):
        p = dict(PROGRESS)
        p["csc_building"] = CSC_BUILDING
        p["csc_cached"] = CSC_CACHED
        p["csc_time"] = CSC_TIME
        p["hvg_ready"] = len(HVG_NAMES) > 0
        p["pacmap_computing"] = PACMAP_COMPUTING
        p["pacmap_ready"] = PACMAP_2D is not None
        p["annot"] = dict(ANNOT_STATUS)
        if len(HVG_NAMES) > 0:
            p["hvg_genes"] = HVG_NAMES[:200]
            if HVG_VAR:
                p["hvg_var"] = {g: round(HVG_VAR[g], 4) for g in HVG_NAMES[:200] if g in HVG_VAR}
        data = json.dumps(p).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def _serve_gene_var(self):
        """Return all genes sorted by variance (descending)."""
        try:
            if ALL_GENE_VAR is None or GENE_NAMES_LIST is None:
                result = {"genes": [], "metric": "variance"}
            else:
                # Sort all genes by variance descending
                order = np.argsort(ALL_GENE_VAR)[::-1]
                genes = []
                for i in order:
                    v = float(ALL_GENE_VAR[i])
                    if v > 0:  # skip zero-variance genes
                        genes.append([str(GENE_NAMES_LIST[i]), round(v, 4)])
                result = {"genes": genes, "metric": "variance", "total": len(GENE_NAMES_LIST)}
            data = json.dumps(result, separators=(",", ":")).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            err = json.dumps({"genes": [], "error": str(e)}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_search(self, query):
        if ADATA is None:
            data = json.dumps([]).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        q = query.strip().upper()
        if not q:
            matches = []
        else:
            matches = [g for g in GENE_NAMES_LIST if q in g.upper()][:50]
        data = json.dumps(matches).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_deg(self, req):
        """Run DEG between two cell groups."""
        if ADATA is None:
            err = json.dumps({"error": "No dataset loaded"}).encode("utf-8")
            self.send_response(503)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)
            return
        try:
            result = run_deg(
                group_a=req["group_a"],
                group_b=req["group_b"],
                test=req.get("test", "wilcoxon"),
            )
            data = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            import traceback
            traceback.print_exc()
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_export(self, req):
        """Export cell subset as h5ad for download."""
        try:
            indices = req["indices"]
            name = req.get("name", "subset")
            fpath, fname = export_h5ad_subset(indices, name)
            fsize = os.path.getsize(fpath)
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
            self.send_header("Content-Length", str(fsize))
            self.end_headers()
            # Stream in chunks — macOS sendall fails on buffers > ~2GB
            CHUNK = 4 * 1024 * 1024  # 4MB
            with open(fpath, "rb") as f:
                while True:
                    chunk = f.read(CHUNK)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
            os.remove(fpath)
        except Exception as e:
            import traceback
            traceback.print_exc()
            # Clean up temp file if it exists
            try:
                if 'fpath' in locals() and os.path.exists(fpath):
                    os.remove(fpath)
            except OSError:
                pass
            err = json.dumps({"error": str(e)}).encode("utf-8")
            try:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(err)))
                self.end_headers()
                self.wfile.write(err)
            except Exception:
                pass  # headers may already be sent

    def _serve_load(self, req):
        """Load an h5ad file from a local path (no upload needed)."""
        try:
            fpath = req.get("path", "")
            print(f"  Load request: path={fpath!r}")
            if not fpath or not os.path.exists(fpath):
                raise FileNotFoundError(f"File not found: {fpath}")
            if not fpath.endswith(".h5ad"):
                raise ValueError("File must be .h5ad")
            fast = req.get("fast_umap", True)
            fast_sub = int(req.get("fast_umap_n", 50000))
            backed = req.get("backed", "off")
            DEG_SETTINGS["fast"] = req.get("fast_deg", True)
            DEG_SETTINGS["max_cells"] = int(req.get("fast_deg_n", 50000))
            PACMAP_SETTINGS["fast"] = req.get("fast_pacmap", True)

            _progress("Loading from local path...", 1)
            def _bg():
                try:
                    with PROCESSING_LOCK:
                        load_and_prepare(fpath, max_cells=0, n_dims_list=[2, 3],
                                         fast_umap=fast, fast_umap_subsample=fast_sub,
                                         backed=backed)
                except AbortError:
                    print("  Load aborted by user")
                    _reset_all()
                    PROGRESS["status"] = "aborted"
                    PROGRESS["message"] = "Load cancelled"
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    PROGRESS["status"] = "error"
                    PROGRESS["message"] = str(e)
            threading.Thread(target=_bg, daemon=True).start()

            result = {"ok": True, "path": fpath}
            data = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            import traceback
            traceback.print_exc()
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_annotate(self, req):
        """Run cell type annotation against marker database."""
        try:
            top_n = req.get("top_n", 50)
            test = req.get("test", "wilcoxon")
            result = annotate_clusters(top_n=top_n, test=test)
            data = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            import traceback
            traceback.print_exc()
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_annotate_llm(self, req):
        """Run cell type annotation using Claude LLM."""
        try:
            if not ANTHROPIC_API_KEY:
                raise ValueError("No API key configured. Start server with --api-key sk-ant-... or set ANTHROPIC_API_KEY env var.")
            top_n = req.get("top_n", 30)
            tissue = req.get("tissue", "")
            result = annotate_clusters_llm(top_n=top_n, tissue_hint=tissue)
            data = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            import traceback
            traceback.print_exc()
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_lineage(self, req):
        """Construct a developmental lineage tree for the current cell types using Claude."""
        try:
            if not ANTHROPIC_API_KEY:
                raise ValueError("No API key configured. Start server with --api-key sk-ant-... or set ANTHROPIC_API_KEY env var.")
            if ADATA is None or CLUSTER_NAMES is None:
                raise ValueError("No dataset loaded")

            # Check cache
            cache_path = Path(LOADED_PATH).with_suffix(".annot_lineage.json") if LOADED_PATH else None
            if cache_path and cache_path.exists():
                try:
                    with open(cache_path) as f:
                        cached = json.load(f)
                    if cached.get("cluster_names") == CLUSTER_NAMES and cached.get("n_cells") == N_CELLS:
                        print(f"  Lineage loaded from cache")
                        result = {"ok": True, "tree": cached["tree"], "cached": True}
                        data = json.dumps(result).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json")
                        self.send_header("Content-Length", str(len(data)))
                        self.end_headers()
                        self.wfile.write(data)
                        return
                except Exception:
                    pass

            # Build prompt with cluster names and cell counts
            cluster_info = []
            from collections import Counter
            counts = Counter(CLUSTER_IDS.tolist())
            for i, name in enumerate(CLUSTER_NAMES):
                entry = f"  Cluster {i}: \"{name}\" ({counts.get(i, 0):,} cells)"
                cluster_info.append(entry)

            # Include Claude annotations if available
            llm_cache_path = Path(LOADED_PATH).with_suffix(".annot_llm.json") if LOADED_PATH else None
            llm_context = ""
            if llm_cache_path and llm_cache_path.exists():
                try:
                    with open(llm_cache_path) as f:
                        llm_data = json.load(f)
                    llm_results = llm_data.get("results", [])
                    if llm_results:
                        llm_lines = []
                        for r in llm_results:
                            cid = r.get("cluster_id", "?")
                            preds = r.get("predictions", [])
                            if preds:
                                pred = preds[0].get("type", "") if isinstance(preds[0], dict) else str(preds[0])
                                llm_lines.append(f"  Cluster {cid}: predicted as \"{pred}\"")
                        if llm_lines:
                            llm_context = "\n\nClaude cell type predictions for these clusters:\n" + "\n".join(llm_lines)
                except Exception:
                    pass

            prompt = f"""You are a developmental biology expert. Given these cell types from a single-cell RNA-seq dataset, construct a developmental lineage tree.

Cell types in this dataset:
{chr(10).join(cluster_info)}
{llm_context}

Instructions:
1. Build a tree showing the developmental hierarchy of these cell types
2. The root should be the last common developmental ancestor of all cell types present
3. Include intermediate progenitor stages that connect the cell types, even if they are not present in the dataset — mark these as "inferred"
4. Each node that corresponds to an actual cluster in the dataset should reference it by cluster_id
5. A single dataset cluster may map to one node. If two clusters are the same developmental identity (e.g. just numbered differently), still give each its own leaf
6. Keep inferred intermediates minimal — only add nodes needed to connect the lineage, not an exhaustive textbook tree
7. Use standard developmental biology nomenclature for inferred nodes

Return ONLY a JSON object with this structure (no markdown, no explanation):
{{
  "root": {{
    "name": "Ancestor Name",
    "present": false,
    "cluster_ids": [],
    "children": [
      {{
        "name": "Progenitor",
        "present": false,
        "cluster_ids": [],
        "children": [
          {{
            "name": "Cell Type A",
            "present": true,
            "cluster_ids": [0],
            "children": []
          }}
        ]
      }}
    ]
  }}
}}

"present" means the cell type exists as a cluster in the dataset (true) or is an inferred developmental intermediate (false).
"cluster_ids" is an array of cluster indices that map to this node (empty for inferred nodes).
Every cluster_id from 0 to {len(CLUSTER_NAMES)-1} must appear exactly once in the tree."""

            print(f"  Requesting lineage tree from Claude ({len(CLUSTER_NAMES)} cell types)...")
            request_body = json.dumps({
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 8192,
                "messages": [{"role": "user", "content": prompt}]
            }).encode("utf-8")

            api_req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=request_body,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01"
                },
                method="POST"
            )

            try:
                with urllib.request.urlopen(api_req, timeout=120) as resp:
                    resp_data = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", errors="replace")
                raise ValueError(f"Claude API error {e.code}: {body[:200]}")

            usage = resp_data.get("usage", {})
            print(f"  Lineage response: {usage.get('input_tokens', 0)} in, {usage.get('output_tokens', 0)} out tokens")

            # Parse response
            text = ""
            for block in resp_data.get("content", []):
                if block.get("type") == "text":
                    text += block["text"]

            text = text.strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[1] if "\n" in text else text[3:]
            if text.endswith("```"):
                text = text[:-3].strip()

            tree = json.loads(text)
            # Accept either {root: ...} or direct node
            if "root" in tree:
                tree = tree["root"]

            # Validate: every cluster_id should appear
            def _collect_ids(node):
                ids = set(node.get("cluster_ids", []))
                for ch in node.get("children", []):
                    ids |= _collect_ids(ch)
                return ids
            found_ids = _collect_ids(tree)
            expected_ids = set(range(len(CLUSTER_NAMES)))
            missing = expected_ids - found_ids
            if missing:
                print(f"  Warning: lineage tree missing cluster_ids: {missing}")

            # Cache
            if cache_path:
                try:
                    cache_obj = {
                        "cluster_names": CLUSTER_NAMES,
                        "n_cells": N_CELLS,
                        "tree": tree
                    }
                    with open(cache_path, "w") as f:
                        json.dump(cache_obj, f)
                    print(f"  Lineage cached to {cache_path.name}")
                except Exception as e:
                    print(f"  Lineage cache write failed: {e}")

            result = {"ok": True, "tree": tree, "cached": False}
            data = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        except Exception as e:
            import traceback
            traceback.print_exc()
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_compute_embedding(self, req):
        """Compute an embedding on demand (e.g. PaCMAP) and return coordinates."""
        global PACMAP_2D, PACMAP_3D
        method = req.get("method", "")
        try:
            if ADATA is None:
                raise ValueError("No dataset loaded")

            if method == "pacmap":
                # Check if already computed
                if PACMAP_2D is not None and PACMAP_3D is not None:
                    result = {"ok": True, "cached": True}
                    data = json.dumps(result).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return

                pca_input = ADATA.obsm.get("X_pca")
                if pca_input is None:
                    raise ValueError("No PCA coordinates available")
                pca_input = pca_input[:, :30].astype(np.float32)
                n_total = pca_input.shape[0]
                PACMAP_SUB = PACMAP_SETTINGS.get("max_cells", 50000) if PACMAP_SETTINGS.get("fast", True) else 0

                # Run PaCMAP in a subprocess to avoid numba/threading segfaults
                import tempfile, subprocess
                with tempfile.TemporaryDirectory() as tmpdir:
                    input_path = os.path.join(tmpdir, "pca_in.npy")
                    out2_path = os.path.join(tmpdir, "pacmap_2d.npy")
                    out3_path = os.path.join(tmpdir, "pacmap_3d.npy")
                    np.save(input_path, pca_input)

                    if PACMAP_SUB > 0 and n_total > PACMAP_SUB:
                        sub_idx = _stratified_subsample(CLUSTER_IDS, PACMAP_SUB,
                                                        np.random.default_rng(42))
                        sub_path = os.path.join(tmpdir, "sub_idx.npy")
                        np.save(sub_path, np.array(sub_idx, dtype=np.int32))
                        script = f"""
import numpy as np, pacmap, time
from scipy.spatial import cKDTree
X = np.load("{input_path}")
sub_idx = np.load("{sub_path}")
X_sub = X[sub_idx]
nn = min(10, max(2, len(sub_idx) // 50))
t0 = time.time()
print(f"  PaCMAP 2D ({{len(sub_idx):,}} / {{X.shape[0]:,}} cells)...")
Y2_sub = pacmap.PaCMAP(n_components=2, n_neighbors=nn, verbose=False).fit_transform(X_sub).astype(np.float32)
print(f"  PaCMAP 3D...")
Y3_sub = pacmap.PaCMAP(n_components=3, n_neighbors=nn, verbose=False).fit_transform(X_sub).astype(np.float32)
print(f"  Projecting remaining cells (k=5 weighted)...")
tree = cKDTree(X_sub)
rest_mask = np.ones(X.shape[0], dtype=bool)
rest_mask[sub_idx] = False
rest_idx = np.where(rest_mask)[0]
dists, knn_idx = tree.query(X[rest_idx], k=5)
weights = 1.0 / (dists + 1e-10)
weights /= weights.sum(axis=1, keepdims=True)
Y2 = np.empty((X.shape[0], 2), dtype=np.float32)
Y3 = np.empty((X.shape[0], 3), dtype=np.float32)
Y2[sub_idx] = Y2_sub; Y3[sub_idx] = Y3_sub
Y2[rest_idx] = np.einsum("nk,nkd->nd", weights, Y2_sub[knn_idx]).astype(np.float32)
Y3[rest_idx] = np.einsum("nk,nkd->nd", weights, Y3_sub[knn_idx]).astype(np.float32)
np.save("{out2_path}", Y2); np.save("{out3_path}", Y3)
print(f"  PaCMAP done ({{time.time()-t0:.1f}}s)")
"""
                    else:
                        script = f"""
import numpy as np, pacmap, time
X = np.load("{input_path}")
nn = min(10, max(2, X.shape[0] // 50))
t0 = time.time()
print(f"  PaCMAP 2D ({{X.shape[0]:,}} cells, {{nn}} neighbors)...")
Y2 = pacmap.PaCMAP(n_components=2, n_neighbors=nn, verbose=False).fit_transform(X).astype(np.float32)
np.save("{out2_path}", Y2)
print(f"  PaCMAP 3D...")
Y3 = pacmap.PaCMAP(n_components=3, n_neighbors=nn, verbose=False).fit_transform(X).astype(np.float32)
np.save("{out3_path}", Y3)
print(f"  PaCMAP done ({{time.time()-t0:.1f}}s)")
"""
                    t0 = time.time()
                    print(f"  Computing PaCMAP in subprocess ({N_CELLS:,} cells)...")
                    proc = subprocess.run(
                        [sys.executable, "-c", script],
                        capture_output=True, text=True
                    )
                    # Print subprocess output
                    if proc.stdout:
                        for line in proc.stdout.strip().split("\n"):
                            print(line)
                    if proc.returncode != 0:
                        stderr = proc.stderr.strip()[-500:] if proc.stderr else "unknown error"
                        raise RuntimeError(f"PaCMAP subprocess failed (exit {proc.returncode}): {stderr}")

                    PACMAP_2D = np.load(out2_path)
                    PACMAP_3D = np.load(out3_path)
                    elapsed = round(time.time() - t0, 1)
                    print(f"  PaCMAP total: {elapsed}s")

                # Save to cache with method-specific keys
                if LOADED_PATH:
                    _pm_sfx = "_quick" if PACMAP_SETTINGS.get("fast", True) else "_full"
                    cache_path = Path(LOADED_PATH).with_suffix(".fleek_cache.npz")
                    if cache_path.exists():
                        try:
                            cached = dict(np.load(cache_path, allow_pickle=False))
                            cached[f"pacmap_2d{_pm_sfx}"] = PACMAP_2D
                            cached[f"pacmap_3d{_pm_sfx}"] = PACMAP_3D
                            np.savez(cache_path, **cached)
                            print(f"  PaCMAP cached ({_pm_sfx.strip('_')})")
                        except Exception:
                            pass

                result = {"ok": True, "elapsed": elapsed}
            else:
                raise ValueError(f"Unknown embedding method: {method}")

            data = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            import traceback
            traceback.print_exc()
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def _serve_abort(self, req):
        """Abort in-progress loading."""
        global ABORT_REQUESTED
        ABORT_REQUESTED = True
        print("  Abort requested by client")
        result = {"ok": True}
        data = json.dumps(result).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_unload(self, req):
        """Unload current dataset and free all memory."""
        global ABORT_REQUESTED
        ABORT_REQUESTED = True  # Stop any background processing
        print("  Unload requested by client")
        _reset_all()
        PROGRESS["status"] = "idle"
        PROGRESS["message"] = ""
        PROGRESS["pct"] = 0
        import gc; gc.collect()
        result = {"ok": True}
        data = json.dumps(result).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_upload(self):
        """Receive an h5ad file upload, save to disk, then process in background."""
        import tempfile
        try:
            length = int(self.headers.get("Content-Length", 0))
            fname = self.headers.get("X-Filename", "upload.h5ad")
            if not fname.endswith(".h5ad"):
                raise ValueError("File must be .h5ad")
            _progress("Receiving upload...", 1)
            fpath = os.path.join(tempfile.gettempdir(), fname)
            received = 0
            with open(fpath, "wb") as f:
                while received < length:
                    chunk = self.rfile.read(min(65536, length - received))
                    if not chunk:
                        break
                    f.write(chunk)
                    received += len(chunk)
            _progress("Upload saved, starting processing...", 3)
            fast = self.headers.get("X-Fast-UMAP", "0") == "1"
            fast_sub = int(self.headers.get("X-Fast-UMAP-N", "50000"))
            backed = self.headers.get("X-Backed", "off")  # "auto", "on", "off"
            # QuickDEG settings
            DEG_SETTINGS["fast"] = self.headers.get("X-Fast-DEG", "1") == "1"
            DEG_SETTINGS["max_cells"] = int(self.headers.get("X-Fast-DEG-N", "50000"))
            PACMAP_SETTINGS["fast"] = self.headers.get("X-Fast-PaCMAP", "1") == "1"

            # Start processing in background thread
            def _bg():
                try:
                    with PROCESSING_LOCK:
                        load_and_prepare(fpath, max_cells=0, n_dims_list=[2, 3],
                                         fast_umap=fast, fast_umap_subsample=fast_sub,
                                         backed=backed)
                except AbortError:
                    print("  Load aborted by user")
                    _reset_all()
                    PROGRESS["status"] = "aborted"
                    PROGRESS["message"] = "Load cancelled"
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    PROGRESS["status"] = "error"
                    PROGRESS["message"] = str(e)

            threading.Thread(target=_bg, daemon=True).start()

            # Respond immediately — client will poll /api/progress
            result = {"processing": True}
            data = json.dumps(result).encode("utf-8")
            self.send_response(202)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            import traceback
            traceback.print_exc()
            PROGRESS["status"] = "error"
            PROGRESS["message"] = str(e)
            err = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(err)))
            self.end_headers()
            self.wfile.write(err)

    def log_message(self, format, *args):
        # Quieter logging
        if "/api/" in str(args[0]):
            return
        super().log_message(format, *args)


def main():
    parser = argparse.ArgumentParser(description="RNA-FLEEK: serve h5ad directly to browser")
    parser.add_argument("h5ad", type=str, nargs="?", default=None,
                        help="Path to h5ad file (optional — can upload via browser)")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--max-cells", type=int, default=0,
                        help="Subsample to this many cells (0 = all)")
    parser.add_argument("--dims", type=str, default="2,3",
                        help="UMAP dims to compute, comma-separated (default: 2,3)")
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--fast-umap", action="store_true",
                        help="Use subsample-and-project for large datasets (>50k cells)")
    parser.add_argument("--fast-umap-n", type=int, default=50000,
                        help="Number of cells for UMAP subsample (default: 50000)")
    parser.add_argument("--backed", type=str, default="off", choices=["auto", "on", "off"],
                        help="Backed mode: auto (detect), on (force disk), off (force RAM, default)")
    parser.add_argument("--api-key", type=str, default="",
                        help="Anthropic API key for Claude cell type annotation (or set ANTHROPIC_API_KEY)")
    parser.add_argument("--no-browser", action="store_true",
                        help="Don't auto-open browser (useful for remote/SSH sessions)")
    args = parser.parse_args()

    if args.api_key:
        global ANTHROPIC_API_KEY
        ANTHROPIC_API_KEY = args.api_key

    dims = [int(d) for d in args.dims.split(",")]

    if args.h5ad:
        load_and_prepare(args.h5ad, max_cells=args.max_cells, n_dims_list=dims,
                         fast_umap=args.fast_umap, fast_umap_subsample=args.fast_umap_n,
                         backed=args.backed)

    server = type('ThreadingHTTPServer', (ThreadingMixIn, HTTPServer), {'daemon_threads': True})((args.host, args.port), FleekHandler)
    url = f"http://{args.host}:{args.port}"
    print(f"\n{'='*50}")
    print(f"  RNA-FLEEK running at: {url}")
    if ADATA is not None:
        print(f"  {N_CELLS:,} cells · {len(CLUSTER_NAMES)} types · {len(GENE_NAMES_LIST):,} genes")
    else:
        print(f"  No dataset loaded — upload via browser")
    print(f"{'='*50}\n")

    # Try to open browser (skip if --no-browser, or if running over SSH)
    is_ssh = os.environ.get("SSH_CLIENT") or os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_TTY")
    if not args.no_browser and not is_ssh:
        try:
            import webbrowser
            webbrowser.open(url)
        except:
            pass
    elif is_ssh:
        print(f"  (SSH session detected — open {url} in your local browser)")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.shutdown()


if __name__ == "__main__":
    main()
