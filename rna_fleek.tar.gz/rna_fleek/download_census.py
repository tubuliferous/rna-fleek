#!/usr/bin/env python3
"""
Download a tissue slice from CELLxGENE Census as a local h5ad file.
Downloads in chunks for reliability — retries failed chunks, shows real progress,
and can resume interrupted downloads.

Usage:
    python download_census.py --tissue blood
    python download_census.py --tissue blood --max-cells 500000
    python download_census.py --tissue liver --chunk-size 50000

Requirements:
    pip install cellxgene-census anndata scipy
"""

import argparse
import os
import sys
import time
import shutil
import tempfile
from pathlib import Path

import numpy as np


def main():
    parser = argparse.ArgumentParser(description="Download Census tissue data as h5ad (chunked)")
    parser.add_argument("--tissue", type=str, required=True,
                        help="tissue_general value (blood, lung, brain, liver, heart, kidney, etc.)")
    parser.add_argument("--max-cells", type=int, default=0,
                        help="Cap cell count (0 = download all)")
    parser.add_argument("--chunk-size", type=int, default=50000,
                        help="Cells per download chunk (default: 50000)")
    parser.add_argument("--output", type=str, default=None,
                        help="Output h5ad path (default: <tissue>_census.h5ad)")
    parser.add_argument("--census-version", type=str, default="stable")
    parser.add_argument("--retries", type=int, default=3,
                        help="Retries per failed chunk (default: 3)")
    args = parser.parse_args()

    out = args.output or f"{args.tissue}_census.h5ad"

    import cellxgene_census
    import anndata as ad
    import scipy.sparse as sp

    print(f"{'='*60}")
    print(f"  CELLxGENE Census Download — {args.tissue}")
    print(f"{'='*60}")

    # ── Step 1: Count cells ──
    print(f"\n[1/4] Opening Census (version: {args.census_version})...")
    census = cellxgene_census.open_soma(census_version=args.census_version)

    obs_filter = f"tissue_general == '{args.tissue}' and is_primary_data == True"

    print(f"[1/4] Counting cells for tissue_general='{args.tissue}'...")
    obs_df = cellxgene_census.get_obs(
        census, "Homo sapiens", value_filter=obs_filter,
        column_names=["soma_joinid", "cell_type"],
    )
    total = len(obs_df)
    n_types = obs_df["cell_type"].nunique()
    print(f"       Found {total:,} cells, {n_types} cell types")

    # ── Step 2: Determine download plan ──
    download_n = total
    if args.max_cells > 0 and total > args.max_cells:
        download_n = args.max_cells
        print(f"\n[2/4] Subsampling to {download_n:,} cells (stratified by cell type)...")
        rng = np.random.default_rng(42)
        keep_idx = []
        types = obs_df["cell_type"].values
        unique_types = np.unique(types)
        for ct in unique_types:
            ct_idx = np.where(types == ct)[0]
            share = max(5, int(round(len(ct_idx) / total * download_n)))
            share = min(share, len(ct_idx))
            chosen = rng.choice(ct_idx, size=share, replace=False)
            keep_idx.append(chosen)
        keep_idx = np.sort(np.concatenate(keep_idx))
        if len(keep_idx) > download_n:
            keep_idx = rng.choice(keep_idx, size=download_n, replace=False)
            keep_idx.sort()
        obs_df = obs_df.iloc[keep_idx]
        download_n = len(obs_df)
        print(f"       Kept {download_n:,} cells across {n_types} types")
    else:
        print(f"\n[2/4] Will download all {download_n:,} cells")
        if download_n > 2_000_000:
            est_gb = download_n * 4e-6
            print(f"       Warning: estimated file ~{est_gb:.0f} GB")
            print(f"       Consider: --max-cells 1000000")

    soma_ids = obs_df["soma_joinid"].to_numpy()

    # ── Step 3: Download in chunks ──
    chunk_size = args.chunk_size
    n_chunks = (download_n + chunk_size - 1) // chunk_size
    print(f"\n[3/4] Downloading {download_n:,} cells in {n_chunks} chunks of {chunk_size:,}")
    print(f"       Retries per chunk: {args.retries}")

    tmp_dir = Path(tempfile.mkdtemp(prefix="census_dl_"))
    print(f"       Temp dir: {tmp_dir}")

    obs_columns = [
        "cell_type", "tissue", "disease", "assay",
        "donor_id", "sex", "development_stage",
        "self_reported_ethnicity", "suspension_type",
    ]

    t_start = time.time()
    total_cells_dl = 0
    failed_chunks = []

    for ci in range(n_chunks):
        start = ci * chunk_size
        end = min(start + chunk_size, download_n)
        chunk_ids = soma_ids[start:end]
        chunk_file = tmp_dir / f"chunk_{ci:04d}.h5ad"

        # Skip if already downloaded (resume support)
        if chunk_file.exists():
            try:
                test = ad.read_h5ad(chunk_file, backed="r")
                if test.n_obs == len(chunk_ids):
                    total_cells_dl += len(chunk_ids)
                    elapsed = time.time() - t_start
                    rate = total_cells_dl / max(elapsed, 0.1)
                    remain = (download_n - total_cells_dl) / max(rate, 1)
                    print(f"  [{ci+1}/{n_chunks}] cached ({len(chunk_ids):,} cells) "
                          f"| {total_cells_dl:,}/{download_n:,} "
                          f"({total_cells_dl/download_n*100:.0f}%)")
                    test.file.close()
                    continue
                test.file.close()
            except:
                pass

        # Download with retries
        success = False
        for attempt in range(1, args.retries + 1):
            try:
                t0 = time.time()
                chunk_adata = cellxgene_census.get_anndata(
                    census,
                    organism="Homo sapiens",
                    obs_coords=chunk_ids,
                    obs_column_names=obs_columns,
                )
                chunk_adata.write_h5ad(chunk_file)
                dt = time.time() - t0

                total_cells_dl += chunk_adata.n_obs
                elapsed = time.time() - t_start
                rate = total_cells_dl / max(elapsed, 0.1)
                remain = (download_n - total_cells_dl) / max(rate, 1)

                print(f"  [{ci+1}/{n_chunks}] {chunk_adata.n_obs:,} cells in {dt:.0f}s "
                      f"| {total_cells_dl:,}/{download_n:,} "
                      f"({total_cells_dl/download_n*100:.0f}%) | "
                      f"~{remain/60:.0f}min left")

                del chunk_adata
                success = True
                break
            except Exception as e:
                print(f"  [{ci+1}/{n_chunks}] FAIL attempt {attempt}/{args.retries}: {e}")
                if attempt < args.retries:
                    wait = 10 * attempt
                    print(f"       Retrying in {wait}s...")
                    time.sleep(wait)

        if not success:
            failed_chunks.append(ci)
            print(f"  [{ci+1}/{n_chunks}] FAILED after {args.retries} attempts, skipping")

    census.close()

    if failed_chunks:
        print(f"\n⚠️  {len(failed_chunks)} chunks failed: {failed_chunks}")
        print(f"    Re-run same command to retry — completed chunks are cached")

    # ── Step 4: Concatenate chunks on disk (no RAM spike) ──
    chunk_files = sorted(tmp_dir.glob("chunk_*.h5ad"))
    if not chunk_files:
        print("\nNo chunks downloaded! Exiting.")
        shutil.rmtree(tmp_dir, ignore_errors=True)
        sys.exit(1)

    n_chunks_done = len(chunk_files)
    print(f"\n[4/4] Concatenating {n_chunks_done} chunks on disk...")
    t0 = time.time()

    # Try anndata's on-disk concat first (anndata >= 0.10)
    try:
        from anndata.experimental import concat_on_disk
        print(f"       Using anndata.experimental.concat_on_disk (memory-efficient)")
        concat_on_disk(
            [str(cf) for cf in chunk_files],
            out,
            join="outer",
            merge="first",
        )
        # Quick read to fix var names and report stats
        combined = ad.read_h5ad(out, backed="r")
        n_obs = combined.n_obs
        n_vars = combined.n_vars
        has_feature_name = "feature_name" in combined.var.columns
        combined.file.close()

        if has_feature_name:
            # Need to fix var index — read just var, modify, rewrite
            import h5py
            with h5py.File(out, "r+") as f:
                if "var" in f and "feature_name" in f["var"]:
                    names = [x.decode() if isinstance(x, bytes) else str(x)
                             for x in f["var"]["feature_name"][...]]
                    # Make unique
                    seen = {}
                    for i, n in enumerate(names):
                        if n in seen:
                            seen[n] += 1
                            names[i] = f"{n}-{seen[n]}"
                        else:
                            seen[n] = 0
                    idx_ds = f["var"]["_index"] if "_index" in f["var"] else f["var"].create_dataset("_index", data=names)
                    if "_index" in f["var"]:
                        del f["var"]["_index"]
                    f["var"].create_dataset("_index", data=np.array(names, dtype="S"))

    except (ImportError, TypeError) as e:
        # Fallback: chunked concat loading one at a time
        print(f"       concat_on_disk not available ({e}), using chunked RAM concat...")
        print(f"       Loading chunks in batches of 20 to limit memory...")

        batch_size = 20
        merged_files = []

        for bi in range(0, len(chunk_files), batch_size):
            batch = chunk_files[bi:bi+batch_size]
            adatas = [ad.read_h5ad(cf) for cf in batch]
            merged = ad.concat(adatas, join="outer", merge="first")
            del adatas

            batch_file = tmp_dir / f"merged_{bi:04d}.h5ad"
            merged.write_h5ad(batch_file)
            merged_files.append(batch_file)
            del merged

            print(f"       Merged batch {bi//batch_size + 1}/"
                  f"{(len(chunk_files) + batch_size - 1)//batch_size} "
                  f"({min(bi+batch_size, len(chunk_files))}/{len(chunk_files)} chunks)")

        # Final merge of batch files
        if len(merged_files) == 1:
            shutil.move(str(merged_files[0]), out)
        else:
            print(f"       Final merge of {len(merged_files)} batch files...")
            adatas = [ad.read_h5ad(mf) for mf in merged_files]
            combined = ad.concat(adatas, join="outer", merge="first")
            del adatas

            if "feature_name" in combined.var.columns:
                combined.var.index = combined.var["feature_name"].astype(str).values
                combined.var_names_make_unique()

            combined.write_h5ad(out)
            n_obs = combined.n_obs
            n_vars = combined.n_vars
            del combined

    dt = time.time() - t0
    size_gb = os.path.getsize(out) / 1e9
    total_time = time.time() - t_start
    print(f"       Saved {size_gb:.1f} GB in {dt:.0f}s")

    shutil.rmtree(tmp_dir, ignore_errors=True)

    print(f"\n{'='*60}")
    print(f"  Done! File: {out} ({size_gb:.1f} GB)")
    print(f"  Total time: {total_time/60:.1f} min")
    print(f"{'='*60}")
    print(f"\nLoad in RNA-FLEEK:")
    print(f"  python fleek_server.py {out} --fast-umap")


if __name__ == "__main__":
    main()
