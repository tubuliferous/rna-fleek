# RNA-FLEEK

**Fast Lightweight Expression Evaluation Kit**

Interactive browser-based visualization and analysis tool for single-cell RNA-seq data. Python server + WebGL frontend in a single HTML file.

## Features

- **3D/2D UMAP** point cloud with WebGL rendering (Three.js)
- **Cell type legend** with search, click-to-toggle, solo mode
- **Gene expression overlay** with viridis gradient, on-demand loading
- **Selection groups** — lasso, shift+click, shift+double-click cell type
- **DEG analysis** — Wilcoxon / t-test, volcano plot, Cohen's d, full gene list
- **QuickMap** — subsample-and-project UMAP for large datasets (500k+ cells)
- **Backed mode** — automatic disk-backed loading for datasets larger than RAM
- **Dark / Light theme**
- **Export** — h5ad subsets per group, DEG tables as TSV
- **State persistence** across refreshes, undo/redo

## Quick Start

```bash
# Install dependencies
pip install scanpy anndata numpy scipy umap-learn

# Start with a dataset
python fleek_server.py your_data.h5ad

# Or start empty and upload via browser
python fleek_server.py

# Large dataset with QuickMap
python fleek_server.py huge_data.h5ad --fast-umap --fast-umap-n 50000
```

Then open http://localhost:8080

## Download Census Data

```bash
# Download from CELLxGENE Census (chunked, resumable)
python download_census.py --tissue liver
python download_census.py --tissue blood --max-cells 500000
```

## Server Options

```
python fleek_server.py [h5ad] [options]

Positional:
  h5ad                  Path to h5ad file (optional)

Options:
  --port PORT           Server port (default: 8080)
  --host HOST           Host address (default: 127.0.0.1)
  --max-cells N         Subsample to N cells (default: all)
  --dims DIMS           UMAP dims to compute (default: 2,3)
  --fast-umap           Use subsample-and-project UMAP
  --fast-umap-n N       Subsample size for QuickMap (default: 50000)
  --backed auto|on|off  Disk-backed mode (default: auto)
```

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| Shift+drag | Lasso select |
| Shift+Opt+drag | Lasso deselect |
| Shift+click | Toggle cell in group |
| Shift+double-click | Toggle cell type in group |
| 1-9 | Switch active group |
| Escape | Clear active group |
| Cmd+[ | Undo |
| Cmd+] | Redo |

## Architecture

- **Server:** `fleek_server.py` — Python HTTP server, loads h5ad, computes UMAPs, serves data, runs DEG
- **Client:** `fleek.html` — single-file Three.js WebGL frontend, canvas volcano plot, full UI
- **Protocol:** Binary "SCRN" format for efficient coordinate + cluster transfer
- **No build tools** — no npm, no webpack, just Python + a browser

## License

MIT
