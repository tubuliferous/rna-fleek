#!/usr/bin/env python3
"""
scRNAseq Visualizer — Data Preprocessor
========================================
Pulls data from CELLxGENE Census (or loads local h5ad) and exports a compact
binary format with both 2D and 3D UMAP embeddings.

Requirements:
    pip install cellxgene-census scanpy numpy

Usage:
    python preprocess_census.py --tissue blood --max-cells 1000000
    python preprocess_census.py --h5ad my_data.h5ad
    python preprocess_census.py --tissue lung --max-cells 2000000 --dims 2  # 2D only

Output:
    cell_data.bin — loadable by fleek_standalone.html
"""

import argparse
import json
import struct
import sys
import time
from pathlib import Path

import numpy as np


def pull_from_census(tissue_general, max_cells, census_version="stable"):
    import cellxgene_census
    import scanpy as sc

    print(f"[1/5] Opening Census (version: {census_version})...")
    census = cellxgene_census.open_soma(census_version=census_version)

    print(f"[2/5] Querying '{tissue_general}' cells from Census...")
    obs_filter = f"tissue_general == '{tissue_general}' and is_primary_data == True"
    obs_df = cellxgene_census.get_obs(
        census, "Homo sapiens", value_filter=obs_filter,
        column_names=["soma_joinid", "cell_type", "tissue", "disease", "assay", "donor_id"],
    )
    total_cells = len(obs_df)
    print(f"    Found {total_cells:,} cells in '{tissue_general}'")

    if total_cells > max_cells:
        print(f"    Subsampling to {max_cells:,} cells...")
        rng = np.random.default_rng(42)
        keep_idx = rng.choice(total_cells, size=max_cells, replace=False)
        keep_idx.sort()
        obs_df = obs_df.iloc[keep_idx]

    soma_joinids = obs_df["soma_joinid"].to_numpy()
    print(f"[3/5] Fetching data for {len(soma_joinids):,} cells...")
    try:
        adata = cellxgene_census.get_anndata(
            census, organism="Homo sapiens", obs_coords=soma_joinids,
            obs_column_names=["cell_type", "tissue", "disease", "assay", "donor_id"],
            obs_embeddings=["scvi"],
        )
        has_embedding = "scvi" in adata.obsm
        print(f"    Got scVI embeddings: {has_embedding}")
    except Exception as e:
        print(f"    Could not get scVI embeddings ({e}), will compute from scratch")
        adata = cellxgene_census.get_anndata(
            census, organism="Homo sapiens", obs_coords=soma_joinids,
            obs_column_names=["cell_type", "tissue", "disease", "assay", "donor_id"],
        )
        has_embedding = False
    census.close()
    return adata, has_embedding


def load_h5ad(path):
    import scanpy as sc
    print(f"[1/5] Loading {path}...")
    adata = sc.read_h5ad(path)
    print(f"    {adata.n_obs:,} cells x {adata.n_vars:,} genes")
    return adata, False


def ensure_neighbors(adata, has_embedding):
    import scanpy as sc
    if "connectivities" in adata.obsp:
        return adata
    if has_embedding and "scvi" in adata.obsm:
        scvi_emb = adata.obsm["scvi"]
        nan_mask = np.isnan(scvi_emb).any(axis=1)
        if nan_mask.sum() > 0:
            print(f"    Removing {nan_mask.sum()} cells with NaN embeddings")
            adata = adata[~nan_mask].copy()
        print("    Using scVI embedding for neighbor graph...")
        sc.pp.neighbors(adata, use_rep="scvi", n_neighbors=15)
    else:
        print("    Running standard preprocessing pipeline...")
        adata.layers["counts"] = adata.X.copy()
        sc.pp.normalize_total(adata, target_sum=1e4)
        sc.pp.log1p(adata)
        sc.pp.highly_variable_genes(adata, n_top_genes=2000, flavor="seurat_v3", layer="counts")
        adata_hvg = adata[:, adata.var.highly_variable].copy()
        sc.pp.scale(adata_hvg, max_value=10)
        sc.tl.pca(adata_hvg, n_comps=50)
        sc.pp.neighbors(adata_hvg, n_pcs=50, n_neighbors=15)
        adata.obsp["distances"] = adata_hvg.obsp["distances"]
        adata.obsp["connectivities"] = adata_hvg.obsp["connectivities"]
        adata.uns["neighbors"] = adata_hvg.uns["neighbors"]
    return adata


def compute_umaps(adata, has_embedding, dims_to_compute):
    """Compute UMAP embeddings for requested dimensionalities."""
    import scanpy as sc

    adata = ensure_neighbors(adata, has_embedding)
    results = {}

    for nd in sorted(dims_to_compute):
        key = f"X_umap_{nd}d"
        existing = f"X_umap"
        # Check if existing UMAP matches
        if existing in adata.obsm and adata.obsm[existing].shape[1] == nd and nd == min(dims_to_compute):
            print(f"[4/5] Found existing {nd}D UMAP, reusing")
            results[nd] = adata.obsm[existing].astype(np.float32)
            continue

        print(f"[4/5] Computing {nd}D UMAP for {adata.n_obs:,} cells...")
        t0 = time.time()
        sc.tl.umap(adata, n_components=nd)
        elapsed = time.time() - t0
        print(f"    {nd}D UMAP computed in {elapsed:.1f}s")
        results[nd] = adata.obsm["X_umap"].astype(np.float32)

    return results


def pick_interesting_genes(adata, n_genes=50):
    import scanpy as sc
    print("    Selecting informative genes...")
    if "cell_type" in adata.obs.columns:
        try:
            if "highly_variable" not in adata.var.columns:
                tmp = adata.copy()
                if "counts" in tmp.layers: tmp.X = tmp.layers["counts"]
                sc.pp.normalize_total(tmp, target_sum=1e4)
                sc.pp.log1p(tmp)
                sc.pp.highly_variable_genes(tmp, n_top_genes=min(n_genes * 4, 2000))
                hvg_names = tmp.var_names[tmp.var.highly_variable].tolist()
            else:
                hvg_names = adata.var_names[adata.var.highly_variable].tolist()
            known_markers = [
                "CD3D","CD3E","CD4","CD8A","CD8B","CD19","MS4A1","CD79A",
                "CD14","LYZ","CST3","FCGR3A","NKG7","GNLY","KLRD1",
                "PPBP","PF4","HBA1","HBB","MARCO","MSR1",
                "EPCAM","KRT18","COL1A1","DCN","PECAM1","VWF",
                "MKI67","TOP2A","IL7R","CCR7","FOXP3",
            ]
            available_markers = [g for g in known_markers if g in adata.var_names]
            all_candidates = list(set(hvg_names[:n_genes * 2] + available_markers))
            return all_candidates[:n_genes]
        except Exception as e:
            print(f"    Warning: marker selection failed ({e})")
    if "highly_variable" in adata.var.columns:
        return adata.var_names[adata.var.highly_variable].tolist()[:n_genes]
    return adata.var_names[:n_genes].tolist()


def export_binary(adata, umap_dict, output_path, n_genes=50):
    """
    Export binary with one or both UMAP embeddings.

    Format v3:
        "SCRN" + uint32 header_len + JSON header + binary blocks

    Binary blocks:
        For each embedding (2d and/or 3d): n_dims arrays of n_cells float32
        Then: cluster_ids (int32), metadata columns (int32 each), gene_expr (float32)
    """
    import scipy.sparse as sp

    print(f"[5/5] Exporting to {output_path}...")
    n_cells = adata.n_obs

    if "cell_type" in adata.obs.columns:
        cell_types = adata.obs["cell_type"].astype("category")
        cluster_ids = cell_types.cat.codes.to_numpy().astype(np.int32)
        cluster_names = cell_types.cat.categories.tolist()
    elif "leiden" in adata.obs.columns:
        clusters = adata.obs["leiden"].astype("category")
        cluster_ids = clusters.cat.codes.to_numpy().astype(np.int32)
        cluster_names = [f"Cluster {c}" for c in clusters.cat.categories]
    else:
        cluster_ids = np.zeros(n_cells, dtype=np.int32)
        cluster_names = ["Unknown"]

    gene_names = pick_interesting_genes(adata, n_genes)
    gene_names = [g for g in gene_names if g in adata.var_names][:n_genes]

    print(f"    Extracting expression for {len(gene_names)} genes...")
    gene_expr_list = []
    for gene in gene_names:
        gene_idx = list(adata.var_names).index(gene)
        col = adata.X[:, gene_idx]
        if sp.issparse(col): col = col.toarray().ravel()
        else: col = np.asarray(col).ravel()
        col = col.astype(np.float32)
        pmax = np.percentile(col[col > 0], 98) if (col > 0).sum() > 10 else col.max()
        if pmax > 0: col = np.clip(col / pmax, 0, 1)
        gene_expr_list.append(col)
    gene_expr = np.stack(gene_expr_list, axis=0)

    metadata_columns = {}
    for col_name in ["tissue", "disease", "assay", "donor_id"]:
        if col_name in adata.obs.columns:
            cats = adata.obs[col_name].astype("category")
            metadata_columns[col_name] = {
                "labels": cats.cat.categories.tolist(),
                "ids": cats.cat.codes.to_numpy().astype(np.int32),
            }

    # Determine which dims we have — pick the highest as the "native" dim
    available_dims = sorted(umap_dict.keys())
    native_dims = max(available_dims)

    header = {
        "version": 3,
        "n_cells": n_cells,
        "n_dims": native_dims,
        "available_dims": available_dims,
        "n_genes": len(gene_names),
        "n_clusters": len(cluster_names),
        "gene_names": gene_names,
        "cluster_names": cluster_names,
        "metadata_columns": {k: {"labels": v["labels"]} for k, v in metadata_columns.items()},
    }
    header_bytes = json.dumps(header, separators=(",", ":")).encode("utf-8")

    with open(output_path, "wb") as f:
        f.write(b"SCRN")
        f.write(struct.pack("<I", len(header_bytes)))
        f.write(header_bytes)

        # Write UMAP axes: for each available dim set, write all axes
        for nd in available_dims:
            umap = umap_dict[nd]
            for d in range(nd):
                f.write(umap[:, d].astype(np.float32).tobytes())

        f.write(cluster_ids.tobytes())
        for col_name in metadata_columns:
            f.write(metadata_columns[col_name]["ids"].tobytes())
        f.write(gene_expr.astype(np.float32).tobytes())

    file_size = Path(output_path).stat().st_size
    dim_str = " + ".join(f"{d}D" for d in available_dims)
    print(f"    Written {file_size / 1e6:.1f} MB")
    print(f"    {n_cells:,} cells, UMAP: {dim_str}, {len(gene_names)} genes, {len(cluster_names)} cell types")
    print(f"\nDone! Serve with: python3 -m http.server 8080")
    print(f"Then open: http://localhost:8080/fleek_standalone.html")


def main():
    parser = argparse.ArgumentParser(description="Preprocess scRNAseq data for web visualizer")
    parser.add_argument("--tissue", type=str, default="blood")
    parser.add_argument("--max-cells", type=int, default=1_000_000)
    parser.add_argument("--n-genes", type=int, default=50)
    parser.add_argument("--dims", type=int, default=0, choices=[0, 2, 3],
                        help="UMAP dims: 0=both 2D+3D (default), 2=2D only, 3=3D only")
    parser.add_argument("--h5ad", type=str, default=None)
    parser.add_argument("--output", type=str, default="cell_data.bin")
    parser.add_argument("--census-version", type=str, default="stable")
    args = parser.parse_args()

    if args.h5ad:
        adata, has_emb = load_h5ad(args.h5ad)
    else:
        adata, has_emb = pull_from_census(args.tissue, args.max_cells, args.census_version)

    if args.dims == 0:
        dims_to_compute = [2, 3]
    else:
        dims_to_compute = [args.dims]

    umap_dict = compute_umaps(adata, has_emb, dims_to_compute)
    export_binary(adata, umap_dict, args.output, n_genes=args.n_genes)


if __name__ == "__main__":
    main()
